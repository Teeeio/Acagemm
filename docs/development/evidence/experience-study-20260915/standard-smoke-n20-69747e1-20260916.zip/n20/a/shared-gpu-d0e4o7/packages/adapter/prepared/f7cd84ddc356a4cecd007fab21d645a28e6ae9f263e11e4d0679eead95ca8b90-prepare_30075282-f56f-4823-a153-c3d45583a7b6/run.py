import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


# --- optimized implementation path -------------------------------------------------
# The op is a tiny elementwise chain (32x256 fp32), so wall time is dominated by
# per-kernel launch overhead, not by arithmetic.  Two independent levers:
#   1. kernel count: fold the constant bias into the first product via addcmul so
#      the whole affine is 2 launches (+1 for relu) instead of 4-6.
#   2. launch overhead: replay a captured CUDA graph so the host enqueues the
#      three kernels with a single graph-launch instead of three dispatches.
# Both paths compute exactly relu(1.25*x + 0.75*y - 0.125); neither writes to x or y.

_CONSTS = {}
_GRAPH_CACHE = {}
_GRAPH_ATTEMPTS = [0]
_GRAPH_ATTEMPT_LIMIT = 16


def _scalar_consts(device, dtype):
    key = (device, dtype)
    consts = _CONSTS.get(key)
    if consts is None:
        consts = (
            torch.full((), -0.125, device=device, dtype=dtype),
            torch.ones((), device=device, dtype=dtype),
        )
        _CONSTS[key] = consts
    return consts


def _eager(x, y):
    bias, ones = _scalar_consts(x.device, x.dtype)
    # launch 1: -0.125 + 1.25*x   (0-dim bias/ones broadcast, no temp tensors)
    out = torch.addcmul(bias, x, ones, value=1.25)
    # launch 2: += 0.75*y, written straight back into `out`
    out = torch.add(out, y, alpha=0.75, out=out)
    # launch 3: relu, in place
    return torch.relu_(out)


def _build_graph(x, y):
    """Capture the three-kernel chain once per (buffer, shape, layout) key."""
    if _GRAPH_ATTEMPTS[0] >= _GRAPH_ATTEMPT_LIMIT:
        return None
    _GRAPH_ATTEMPTS[0] += 1
    try:
        graph = torch.cuda.CUDAGraph()
        # Warm up on a side stream so lazy init / allocator growth stays out of capture.
        warmup = torch.cuda.Stream()
        warmup.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(warmup):
            _eager(x, y)
            _eager(x, y)
        torch.cuda.current_stream().wait_stream(warmup)
        with torch.cuda.graph(graph, stream=torch.cuda.Stream()):
            out = _eager(x, y)
        return graph, out
    except Exception:
        # Any capture problem (unsupported build, active capture, graph pool limits)
        # silently degrades to the eager 3-kernel path.
        return None


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if (x.is_cuda and y.is_cuda and x.dtype == torch.float32 and y.dtype == torch.float32
            and x.shape == y.shape and x.device == y.device):
        # Replay is only valid while the captured buffers are the ones being read,
        # so the graph is keyed on the actual data pointers plus shape/stride.
        key = (x.data_ptr(), y.data_ptr(), x.device, x.shape, x.stride(), y.stride())
        entry = _GRAPH_CACHE.get(key)
        if entry is None:
            entry = _build_graph(x, y)
            if entry is not None:
                _GRAPH_CACHE[key] = entry
        if entry is not None:
            entry[0].replay()
            return entry[1]
    return _eager(x, y)
