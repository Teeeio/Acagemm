"""Generic affine operator: relu(x * 1.25 + y * 0.75 - 0.125).

Harness contract:
  get_inputs()            -> the primary (32x256) input bundle
  get_test_cases()        -> 4 named correctness cases (minimal/representative/boundary/ragged)
  get_benchmark_inputs()  -> named benchmark profiles, "primary" first
  reference(inputs)       -> independent correctness oracle (unchanged semantics)
  run(inputs)             -> implementation under test (optimized path)
"""

import torch

# Scalars are Python floats; they broadcast against the fp32 tensors without
# materializing any device-side constant tensor.
_SCALE_X = 1.25
_SCALE_Y = 0.75
_BIAS = 0.125


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * _SCALE_X + inputs['y'] * _SCALE_Y - _BIAS)


def run(inputs):
    # Optimization: the baseline allocated two full-size buffers (the affine
    # expression result plus a redundant .clone()) and launched 4 elementwise
    # kernels (mul, mul, add, sub) before relu. Here the whole chain is
    # accumulated in place into a single output buffer, so only one allocation
    # and 3 elementwise kernels (mul, add, sub) plus the in-place relu run.
    # Arithmetic order is preserved exactly: ((x * 1.25) + y * 0.75) - 0.125,
    # so results stay bit-identical to the reference within tolerance.
    x = inputs['x']
    y = inputs['y']

    out = torch.mul(x, _SCALE_X)
    out.add_(y, alpha=_SCALE_Y)
    out.sub_(_BIAS)
    return torch.relu_(out)
