import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Bounded optimization vs naive_v0:
    #  - drop the redundant trailing .clone() (the tensor is already a fresh,
    #    non-aliased allocation, so the copy only added a kernel launch)
    #  - fold the "y * 0.75" temporary into an in-place alpha-add, and run the
    #    bias subtract / relu in place on the fresh intermediate.
    # Same arithmetic and same operand evaluation order as reference(inputs):
    #   ((x * 1.25) + (y * 0.75)) - 0.125, then relu.
    out = torch.mul(inputs['x'], 1.25)
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    return out.relu_()
