import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Cached 0-dim constant tensor for the -0.125 bias, keyed by (device, dtype).
# It is read-only and broadcasts against any input shape, so no per-shape buffers
# and no per-call host-to-device copies are needed.
_BIAS = {}

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    key = (x.device, x.dtype)
    bias = _BIAS.get(key)
    if bias is None:
        bias = torch.tensor(-0.125, device=x.device, dtype=x.dtype)
        _BIAS[key] = bias
    # 3 kernels total (baseline eager chain was 6, previous in-place chain 4):
    #   k1: out = -0.125 + 1.25 * x   (constant folded into the alpha-scaled add)
    #   k2: out += 0.75 * y           (in-place, no allocation)
    #   k3: out = relu(out)           (in-place, no allocation)
    # Math identity preserved: relu(1.25*x + 0.75*y - 0.125).
    out = torch.add(bias, x, alpha=1.25)
    out.add_(y, alpha=0.75)
    return out.relu_()
