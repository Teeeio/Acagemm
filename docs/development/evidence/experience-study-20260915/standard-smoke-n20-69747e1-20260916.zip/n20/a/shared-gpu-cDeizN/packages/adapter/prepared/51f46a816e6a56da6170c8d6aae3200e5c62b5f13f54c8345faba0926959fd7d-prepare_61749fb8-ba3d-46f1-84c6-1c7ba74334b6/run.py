import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Single fused pass: one allocation, all remaining steps in-place.
    # Removes the redundant device copy (clone) and the two temporary
    # intermediates (y * 0.75, ... - 0.125) that the baseline materialized.
    # Arithmetic order is identical to reference(), so results are bit-stable.
    value = torch.mul(inputs['x'], 1.25)
    value.add_(inputs['y'], alpha=0.75)
    value.sub_(0.125)
    value.relu_()
    return value
