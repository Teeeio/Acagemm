import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


# ---------------------------------------------------------------------------
# Optimized implementation path.
#
# The op is tiny (32x256 fp32 = 8 KiB of data), so wall-clock latency is
# dominated by per-op CPU dispatch + kernel-launch cost, not by arithmetic.
# Two levers are applied:
#   1. The elementwise chain is reduced to one fresh allocation plus in-place
#      updates (no intermediate temporaries, no redundant copy).
#   2. After the input tensors of a given (x, y) pair have been seen once, the
#      whole chain is captured into a CUDA graph bound to those exact buffers
#      and replayed afterwards. Replay still reads the *current* contents of
#      x and y, so results stay correct if data is rewritten in place; it just
#      removes repeated Python dispatch and per-kernel launch overhead.
# Replay is only attempted for tensors we already saw (identity-checked), so a
# caller that hands us freshly allocated tensors every call simply keeps the
# eager path and never pays for capture.
# ---------------------------------------------------------------------------

_MAX_CACHE_ENTRIES = 16
_GRAPH_CACHE = {}


def _eager(x, y):
    """relu(1.25*x + 0.75*y - 0.125): one fresh buffer, rest in place."""
    out = torch.mul(x, 1.25)
    out.add_(y, alpha=0.75)
    out.sub_(0.125)
    out.relu_()
    return out


def _capture(x, y):
    """Capture _eager(x, y) into a CUDA graph bound to x/y's memory."""
    side = torch.cuda.Stream()
    side.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side):
        for _ in range(3):
            warm = _eager(x, y)
    torch.cuda.current_stream().wait_stream(side)
    del warm

    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph, stream=side):
        out = _eager(x, y)
    return graph, out


def run(inputs):
    x = inputs['x']
    y = inputs['y']

    if (not isinstance(x, torch.Tensor) or not isinstance(y, torch.Tensor)
            or not x.is_cuda or not y.is_cuda or x.shape != y.shape):
        return _eager(x, y)

    key = (id(x), id(y))
    entry = _GRAPH_CACHE.get(key)
    if entry is None or entry['x'] is not x or entry['y'] is not y:
        # First sighting of this exact (x, y) pair: compute eagerly and
        # remember the buffers for a possible capture on the next call.
        entry = {'x': x, 'y': y, 'graph': None, 'out': None, 'disabled': False}
        _GRAPH_CACHE[key] = entry
        if len(_GRAPH_CACHE) > _MAX_CACHE_ENTRIES:
            _GRAPH_CACHE.pop(next(iter(_GRAPH_CACHE)))
        return _eager(x, y)

    if entry['graph'] is None and not entry['disabled']:
        try:
            if torch.cuda.is_current_stream_capturing():
                entry['disabled'] = True
            else:
                entry['graph'], entry['out'] = _capture(x, y)
        except Exception:
            entry['disabled'] = True
            entry['graph'] = None
            entry['out'] = None

    if entry['graph'] is None:
        return _eager(x, y)

    entry['graph'].replay()
    return entry['out']
