import torch

# Kernel accounting for run(inputs) = relu(1.25*x + 0.75*y - 0.125):
#   baseline : x*1.25, y*0.75, add, sub, relu, clone      -> 6 kernels
#   round 1  : x*1.25, add_, sub_, relu_                  -> 4 kernels
#   this one : add(K, x, alpha=1.25), add_(y, alpha=0.75),
#              relu_                                      -> 3 kernels
# The bias (-0.125) is folded into a cached constant tensor so the first
# multiply and the subtraction collapse into a single torch.add call, and the
# two remaining steps run in place on that fresh tensor. Cached per
# (shape, dtype, device); built once per shape, never mutated afterwards.
_BIAS = -0.125
_BIAS_CACHE = {}


def _bias_like(x):
    key = (tuple(x.shape), x.dtype, x.device)
    bias = _BIAS_CACHE.get(key)
    if bias is None:
        bias = torch.full(key[0], _BIAS, dtype=x.dtype, device=x.device)
        _BIAS_CACHE[key] = bias
    return bias


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    x = inputs['x']
    # (1.25*x - 0.125) as a single elementwise kernel:
    value = torch.add(_bias_like(x), x, alpha=1.25)
    # + 0.75*y and relu in place: two more kernels, no extra allocation, no copy.
    value.add_(inputs['y'], alpha=0.75)
    return torch.relu_(value)
