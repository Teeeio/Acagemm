import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Single-buffer in-place chain: relu(1.25*x + 0.75*y - 0.125) is built on one
    # freshly allocated output tensor instead of the eager broadcast expression.
    # This removes the baseline's trailing .clone() (a full redundant device copy
    # of the finished result) plus the intermediate temporaries for x*1.25,
    # y*0.75, the sum and the difference: 6 kernel launches + 6 allocations down
    # to 4 launches + 1 allocation. Same float32 math and rounding order as the
    # reference; no in-place mutation of the caller's inputs.
    out = torch.mul(inputs['x'], 1.25)
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    out.relu_()
    return out
