import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Scalar constants used to fold the offset and the scales into fused multiply-add
# kernels. They are materialized lazily on first use so that importing this file
# never touches the CUDA context, and they are reused across calls.
_CONSTANTS = {}

def _constants(device, dtype):
    key = (str(device), dtype)
    cached = _CONSTANTS.get(key)
    if cached is None:
        cached = (
            torch.tensor(-0.125, device=device, dtype=dtype),
            torch.ones((), device=device, dtype=dtype),
        )
        _CONSTANTS[key] = cached
    return cached

def run(inputs):
    # Same math as reference(inputs): relu(1.25 * x + 0.75 * y - 0.125).
    # The offset is folded into the first fused multiply-add so the whole
    # operator is three kernels writing into one output buffer:
    #   out  = -0.125 + 1.25 * x * 1        (addcmul)
    #   out += 0.75 * y * 1                 (addcmul_, in place)
    #   out  = max(out, 0)                  (relu_, in place)
    # No extra full-tensor temporaries and no redundant copy of the result.
    x = inputs['x']
    y = inputs['y']
    neg, one = _constants(x.device, x.dtype)
    out = torch.addcmul(neg, x, one, value=1.25)
    out.addcmul_(y, one, value=0.75)
    out.relu_()
    return out
