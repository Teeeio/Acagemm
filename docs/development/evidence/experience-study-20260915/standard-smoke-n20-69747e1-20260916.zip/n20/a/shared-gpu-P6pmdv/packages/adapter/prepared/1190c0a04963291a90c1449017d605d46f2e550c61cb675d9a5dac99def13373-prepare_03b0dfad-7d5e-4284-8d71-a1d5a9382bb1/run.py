import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Optimized: single allocation + fused in-place chain.
    # 1) drop the redundant device copy (.clone() -> full extra kernel + alloc)
    # 2) avoid the two temporary tensors from `x * 1.25` and `y * 0.75` and the
    #    intermediate add by writing into one output buffer in place.
    # Kernel chain: mul(1.25) -> add_(y, alpha=0.75) -> sub_(0.125) -> relu_()
    # (4 launches, 1 allocation) instead of mul,mul,add,sub,relu,clone (6, 3).
    out = inputs['x'].mul(1.25)
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    return out.relu_()
