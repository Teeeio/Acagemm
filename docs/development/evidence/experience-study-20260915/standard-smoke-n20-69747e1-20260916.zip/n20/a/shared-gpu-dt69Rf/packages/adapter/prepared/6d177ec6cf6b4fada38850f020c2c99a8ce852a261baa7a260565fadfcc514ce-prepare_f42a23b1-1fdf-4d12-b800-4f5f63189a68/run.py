import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


# ---------------------------------------------------------------------------
# Optimised implementation of run(inputs).
#
# The whole operator is one elementwise chain, so latency is dominated by the
# number of kernel launches rather than by arithmetic. Two changes:
#
#   1. 5 launches -> 3: the scalar bias and both coefficients are folded into
#      two addcmul calls, so the affine combination and the clamp cost three
#      launches instead of mul/add/sub/relu/clone.
#   2. Optional replay of that chain from a cached CUDA graph, which removes
#      the per-launch CPU dispatch cost between the three kernels. Graphs are
#      keyed on the live input buffers (address, shape, layout), the captured
#      result is cloned before it is handed out, and any failure permanently
#      falls back to the plain eager chain.
# ---------------------------------------------------------------------------

_ONE = None
_BIAS = None


def _affine_relu(x, y):
    """relu(1.25*x + 0.75*y - 0.125) in three kernels."""
    global _ONE, _BIAS
    one = _ONE
    if one is None or one.device != x.device or one.dtype != x.dtype:
        one = torch.ones((), device=x.device, dtype=x.dtype)
        bias = torch.full((), -0.125, device=x.device, dtype=x.dtype)
        _ONE, _BIAS = one, bias
    else:
        bias = _BIAS
    out = torch.addcmul(bias, x, one, value=1.25)
    out.addcmul_(y, one, value=0.75)
    out.clamp_min_(0.0)
    return out


_GRAPH_CACHE = {}
_GRAPH_LIMIT = 12
_GRAPH_ENABLED = True


def _capture(x, y):
    """Warm up on a side stream, then capture the chain into a CUDA graph."""
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):
            _affine_relu(x, y)
    torch.cuda.current_stream().wait_stream(stream)

    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        out = _affine_relu(x, y)
    graph.replay()
    return graph, out


def run(inputs):
    global _GRAPH_ENABLED
    x = inputs['x']
    y = inputs['y']
    if _GRAPH_ENABLED:
        key = (x.data_ptr(), y.data_ptr(), x.shape, x.stride(), y.stride(), x.dtype)
        entry = _GRAPH_CACHE.get(key)
        if entry is not None:
            entry[0].replay()
            return entry[1].clone()
        if x.is_cuda and len(_GRAPH_CACHE) < _GRAPH_LIMIT:
            try:
                entry = _capture(x, y)
            except Exception:
                _GRAPH_ENABLED = False
                _GRAPH_CACHE.clear()
            else:
                _GRAPH_CACHE[key] = entry
                entry[0].replay()
                return entry[1].clone()
        else:
            _GRAPH_ENABLED = False
            _GRAPH_CACHE.clear()
    return _affine_relu(x, y)
