import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Constant shift term (-0.125) materialised once per (shape, dtype, device).
# It depends only on metadata, never on input values, so reusing it across
# calls is safe and removes one fill kernel from every invocation.
_SHIFT_CACHE = {}

def _shift_like(x):
    key = (x.shape, x.dtype, x.device)
    shift = _SHIFT_CACHE.get(key)
    if shift is None:
        shift = torch.full(x.shape, -0.125, dtype=x.dtype, device=x.device)
        _SHIFT_CACHE[key] = shift
    return shift

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if x.shape != y.shape:
        # Broadcast case: fall back to the generic expression.
        return torch.relu(x * 1.25 + y * 0.75 - 0.125)
    # 3 kernel launches, no temporaries, no redundant device copy:
    #   1) out  = 1.25 * x - 0.125   (shift folded into the multiply via alpha)
    #   2) out += 0.75 * y           (alpha avoids a y*0.75 temporary)
    #   3) out  = relu(out)          (in place)
    out = torch.empty_like(x)
    torch.add(_shift_like(x), x, alpha=1.25, out=out)
    out.add_(y, alpha=0.75)
    out.relu_()
    return out
