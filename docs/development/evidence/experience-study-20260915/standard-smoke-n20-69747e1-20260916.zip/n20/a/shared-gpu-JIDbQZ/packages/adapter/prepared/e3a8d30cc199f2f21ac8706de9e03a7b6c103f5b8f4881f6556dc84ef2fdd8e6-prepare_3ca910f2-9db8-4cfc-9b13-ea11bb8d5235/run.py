import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# 0-dim device scalars (bias and multiplicative identity) used to fold the bias and the
# output scale into a single elementwise kernel. Constants only: never derived from
# inputs and never reused as an output buffer.
_SCALARS = {}

def _scalars(device):
    pair = _SCALARS.get(device)
    if pair is None:
        pair = (torch.tensor(-0.125, dtype=torch.float32, device=device),
                torch.tensor(1.0, dtype=torch.float32, device=device))
        _SCALARS[device] = pair
    return pair

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    bias, one = _scalars(x.device)

    # 1.25*x + 0.75*y - 0.125 == 2*(0.625*x + 0.375*y) - 0.125, so both input scalings
    # collapse into a single lerp kernel (0.375 is exactly representable).
    out = torch.lerp(x, y, 0.375)
    # Bias and output scale collapse into one addcmul kernel: 2*out - 0.125.
    out = torch.addcmul(bias, out, one, value=2.0)
    # Activation is done in place on the freshly allocated buffer; the caller's
    # inputs are read-only here and the returned tensor is never reused across calls.
    out.relu_()
    return out
