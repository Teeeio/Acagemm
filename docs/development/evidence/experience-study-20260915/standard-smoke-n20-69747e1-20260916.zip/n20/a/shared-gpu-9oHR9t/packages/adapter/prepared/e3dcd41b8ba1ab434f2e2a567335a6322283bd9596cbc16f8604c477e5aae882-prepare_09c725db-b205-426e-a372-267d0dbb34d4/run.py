import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _compute(x, y):
    # out = relu(1.25 * x + 0.75 * y - 0.125), 4 eager kernels, no redundant copy.
    # Every in-place step touches only the freshly allocated tensor, so inputs are
    # never mutated and repeated invocations stay independent.
    out = torch.mul(y, 0.75)
    out.add_(x, alpha=1.25)
    out.sub_(0.125)
    out.clamp_min_(0.0)
    return out


# The eager chain above is dominated by per-kernel launch/dispatch overhead on a
# 32x256 FP32 tile, not by GPU work.  Capturing it once per (pointer, shape,
# dtype, device) key into a CUDA graph turns the steady-state call into a single
# graph launch; the graph reads/writes the very same buffers, so the numerics are
# bit-identical to the eager path.
_GRAPH_CACHE = {}
_GRAPH_DISABLED = False
_MAX_GRAPH_ENTRIES = 16


def _graph_key(x, y):
    return (x.device, x.dtype, tuple(x.shape), tuple(x.stride()),
            tuple(y.shape), tuple(y.stride()), x.data_ptr(), y.data_ptr())


def _try_graph(x, y):
    global _GRAPH_DISABLED
    if _GRAPH_DISABLED:
        return None
    key = _graph_key(x, y)
    entry = _GRAPH_CACHE.get(key)
    if entry is not None:
        entry[0].replay()
        return entry[1]
    if len(_GRAPH_CACHE) >= _MAX_GRAPH_ENTRIES:
        # Inputs are not pointer-stable; stop paying capture cost.
        _GRAPH_DISABLED = True
        return None
    try:
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                _compute(x, y)
        torch.cuda.current_stream().wait_stream(side)

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out = _compute(x, y)
        _GRAPH_CACHE[key] = (graph, out)
        graph.replay()
        return out
    except Exception:
        _GRAPH_DISABLED = True
        _GRAPH_CACHE.clear()
        return None


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if x.is_cuda and y.is_cuda:
        out = _try_graph(x, y)
        if out is not None:
            return out
    return _compute(x, y)
