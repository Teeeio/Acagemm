import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Fused in-place affine + ReLU: no redundant device copy, one allocation.
    # Kernel count drops 6 -> 4 (baseline: mul, mul, add, sub, relu, clone).
    # Intermediate rounding steps are identical to reference():
    #   1.25*x, then + 0.75*y, then - 0.125, then relu  ->  bit-identical output.
    out = inputs['x'] * 1.25           # only allocation (no .clone(), no y*0.75 temp)
    out.add_(inputs['y'], alpha=0.75)  # 1.25*x + 0.75*y
    out.sub_(0.125)                    # ... - 0.125
    out.clamp_min_(0.0)                # relu(...)
    return out
