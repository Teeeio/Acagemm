"""Generic affine GPU operator: out = relu(1.25 * x + 0.75 * y - 0.125), FP32/CUDA.

Baseline cost per call: five elementwise kernel launches (mul, mul, add, sub,
relu) plus a redundant device clone, each dispatched from Python.  For a
32x256 tensor the work is ~8K floats, so the call is entirely launch/dispatch
bound rather than bandwidth bound.

This implementation keeps the reference order of operations bit-for-bit, but:

1. folds the whole chain into ONE allocation with in-place updates
   (mul -> add_(alpha) -> sub_ -> clamp_min_), removing the intermediate
   temporaries and the redundant clone, and
2. records that fixed kernel sequence into a CUDA graph keyed by the input
   memory layout, so a steady-state call is a single graph launch instead of
   five Python dispatches plus five kernel launches.

The graph is only adopted after (a) replay is verified against the eager chain
and (b) a device-side timing comparison shows replay is actually faster than
the eager chain; otherwise the eager chain is used for that layout.  Input
tensors are retained by the cache entry so captured device pointers can never
be recycled while a graph is live.  Any capture failure permanently disables
the graph path and falls back to the eager chain.
"""
import torch

_ALPHA = 1.25
_BETA = 0.75
_BIAS = 0.125

# Sentinel returned by dict.get for "no entry recorded for this layout".
_MISSING = object()

_STATE = {
    'entries': {},      # layout key -> (graph, static_out, x, y) or None for "use eager"
    'disabled': False,  # set after any capture failure
    'max_entries': 32,
}


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _affine_relu(x, y):
    """Eager chain: one allocation, three in-place updates, same rounding order."""
    out = x * _ALPHA
    out.add_(y, alpha=_BETA)
    out.sub_(_BIAS)
    out.clamp_min_(0.0)
    return out


def _layout_key(x, y):
    return (x.data_ptr(), tuple(x.shape), tuple(x.stride()), x.dtype,
            y.data_ptr(), tuple(y.shape), tuple(y.stride()), y.dtype)


def _time_ms(fn, iters=20):
    """Device-side elapsed time per call, including inter-launch gaps."""
    for _ in range(3):
        fn()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(iters):
        fn()
    end.record()
    torch.cuda.synchronize()
    return start.elapsed_time(end) / iters


def _record_graph(x, y):
    """Capture the eager chain; return (graph, out, x, y) or None if not worth it."""
    side = torch.cuda.Stream()
    side.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side):
        for _ in range(2):
            _affine_relu(x, y)
    torch.cuda.current_stream().wait_stream(side)

    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        static_out = _affine_relu(x, y)

    # Replay must reproduce the eager result before this graph is trusted.
    graph.replay()
    torch.cuda.synchronize()
    expected = _affine_relu(x, y)
    torch.cuda.synchronize()
    if not bool(torch.allclose(static_out, expected, atol=1e-4, rtol=1e-4)):
        return None

    # Only keep the graph if a single replay launch beats the eager chain.
    if _time_ms(graph.replay) >= _time_ms(lambda: _affine_relu(x, y)):
        return None

    return (graph, static_out, x, y)


def run(inputs):
    x = inputs['x']
    y = inputs['y']

    entries = _STATE['entries']
    if _STATE['disabled'] or not (x.is_cuda and y.is_cuda) or x.numel() == 0:
        return _affine_relu(x, y)

    key = _layout_key(x, y)
    entry = entries.get(key, _MISSING)
    if entry is not _MISSING:
        if entry is None:
            return _affine_relu(x, y)
        entry[0].replay()
        return entry[1]

    if len(entries) >= _STATE['max_entries']:
        return _affine_relu(x, y)

    try:
        entry = _record_graph(x, y)
    except Exception:
        _STATE['disabled'] = True
        return _affine_relu(x, y)

    entries[key] = entry
    if entry is None:
        return _affine_relu(x, y)

    entry[0].replay()
    return entry[1]
