# MIS_MU4BVU6C — Direction Assessment & Acquisition Record

## 0. Source acquisition outcome

- Local Source Registry is **empty**: `.operator-studio/source-registry.json` = `{"schemaVersion":2,"sources":[]}`,
  and `projects/affine/sources/` has no children. Local selection impossible.
- Remote candidates found and **rejected as unusable**:
  - `YangyangFu/kernel-fusion` — CUDA extension library (`setup.py`, `CMakeLists.txt`, `Makefile`,
    `src/cuda/kernels/`). Requires nvcc build + dependency installation. No affine/`addcmul` fusion anyway.
  - `JR-Wesley/CUDA-Python-Op-Lib` — same class (compiled CUDA op library).
- Execution adapter is `python-shared-gpu`, `languages: ["python"]`, `build: {}`; the Mission forbids
  installing dependencies and only permits editing `run.py`. A compiled source can never be materialized.
- The operator is 3 lines of pure PyTorch and its optimal form needs only `torch.addcmul` / `torch.relu_`
  from the already-installed `torch 2.6.0+cu124`. → **semanticFallback**.

## 1. What the measurements actually say

Hardware: RTX 3060 Laptop (sm86), 6144 MiB, driver 551.78, local-shared-gpu.

| quantity | value (us) | / 1.024 |
|---|---|---|
| reference p50 (primary 32x256) | 15.36 | 15 |
| candidate-01 p50 (primary) | 12.288 | 12 |
| reference p50 (small 2x32) | 14.336 | 14 |

Three facts:

1. **15.36 : 12.288 = 5 : 4 exactly.** The only change in candidate-01 was deleting a trailing
   `.clone()` — i.e. exactly one kernel launch. One launch ≈ 15.36/5 ≈ **3.07 us**.
2. **All values are integer multiples of 1.024 us.** The metric is quantized in 1.024 us steps.
3. **The "small" profile has 64 elements; the primary has 8192 — a 128x difference — yet latency moves
   by ONE quantum (15.36 -> 14.336).** The 32 KB working set is L2-resident (RTX 3060 L2 = 3 MB).

**Conclusion: latency is pure per-kernel-launch/dispatch overhead. Arithmetic and bandwidth are free.**
The whole optimization surface is the kernel count.

- Baseline `reference()`: 5 eager kernels -> 15.36 us.
- candidate-01: 4 kernels -> 12.288 us (speedup 1.25x). PASSED 4/4 correctness.
- Eager floor for `relu(1.25x + 0.75y - 0.125)`: **3 kernels** (2x `addcmul` + 1x `relu_`), because
  PyTorch has no 2-input affine primitive and `relu` cannot fold into `addcmul`.
- Absolute floor: **1 kernel ≈ 3.07 us ≈ 5x**, i.e. ~80% reduction. That is the entire available prize.

## 2. Required bar is unreachable by construction

"提升至少 99.9999%" = speedup >= 1e6x. From a 15.36 us baseline that demands **<= 1.54e-5 us** (≈15
femtoseconds) latency. The measurement quantum alone is 1.024 us. **No implementation — not even a
zero-kernel no-op — can register on this scale.** Further rounds spent "chasing the target" are
guaranteed zero-ROI; the only rational objective is to bank the best correct, bounded implementation.

## 3. Root-cause correction for candidate-03

The round log states the failure was a *"graph-path scoping defect"*. That is a **misdiagnosis**. The real
defect is one line of arithmetic. candidate-03's `_affine_relu`:

```python
scaled  = torch.addcmul(x, y, _const(0.75, x))                        # x + 0.75*y
shifted = torch.addcmul(_const(-0.125, x), scaled, _const(1.25, x))   # -0.125 + 1.25*(x + 0.75*y)
return torch.relu_(shifted)
```

The 1.25 is applied to the **whole** `scaled` tensor, so `y` ends up with coefficient
`1.25 * 0.75 = 0.9375`, not `0.75`.

Check against the reported failure on the minimal (1,1) case, where
`x = linspace(-2,2,1)+3 = 1.0` and `y = flip(x) = 1.0`:

- correct: `1.25(1) + 0.75(1) - 0.125 = 1.875`
- candidate-03: `1.25(1) + 0.9375(1) - 0.125 = 2.0625`
- abs diff = **0.1875**  ← reported "Greatest absolute difference: 0.1875"
- rel diff = 0.1875 / 1.875 = **0.1**  ← reported "Greatest relative difference: 0.10000000149"

Exact match to the digit. The previous round was chasing a ghost; CUDA graphs were never the problem —
the affine algebra was wrong. (candidate-02's `_affine_relu` is the *correct* form:
`addcmul(bias, x, ones, 1.25)` then `addcmul(out, y, ones, 0.75)` then `relu_`.)

## 4. Verdict: SWITCH

**Abandon the CUDA-graph / launch-reduction direction. Keep the algebra.**

Reasons:
- **Not converging, it regressed.** Three rounds; the last produced a hard correctness failure where
  candidate-01 had passed. The stated root cause is wrong (section 3), so the team is optimizing against
  an incorrect model of the failure.
- **Capped ceiling.** The direction's best case is ~5x; the bar is 1e6x. Value is bounded and small.
- **Risk concentrated in the failing mechanism.** Returning a graph's static output buffer is a
  documented correctness landmine — see [pytorch/pytorch#99368](https://github.com/pytorch/pytorch/pull/99368)
  (making autocast cache / buffer stealing aware of cudagraph static output tensors) and the upstream fix
  "Fix CUDAGraph stale output checks for cached tensors" (#184368). The harness holds the returned tensor;
  the next replay overwrites it in place. That alone reproduces the "1/1 mismatched" signature.

### (1) Easiest ROI — land this first

Pure-eager, shape-agnostic, **zero** module state, **no** CUDA graphs, **no** input aliasing:

```python
_CONSTS = {}

def _const(value, like):
    key = (value, like.device.type, like.device.index, like.dtype)
    c = _CONSTS.get(key)
    if c is None:
        c = torch.tensor(value, dtype=like.dtype, device=like.device).reshape(1, 1)
        _CONSTS[key] = c
    return c

def run(inputs):
    x, y = inputs['x'], inputs['y']
    out = torch.addcmul(_const(-0.125, x), x, _const(1.0, x), 1.25)  # 1.25*x - 0.125
    out = torch.addcmul(out, y, _const(1.0, x), 0.75)                 # + 0.75*y
    return torch.relu_(out)                                           # in place, call-owned tensor
```

3 kernels -> expected ~7.7–9.2 us vs the 15.36 us reference => **~1.7–2.0x**, a further ~25–40% cut over
candidate-01's 12.288 us. Coefficients verified: `1.25x + 0.75y - 0.125` exactly.

### (2) Low-ROI traps — stop investing

- **CUDA-graph replay / static output buffers.** Saves at most ~2 launches against a 3.07 us quantum,
  while adding per-shape capture caches, capture-in-timed-region, stream-ordering, and the static-output
  aliasing hazard. Highest risk, smallest yield. This is where candidate-03 died.
- **Chasing the 99.9999% bar.** Unreachable (section 2). Zero-ROI by construction.
- **Sub-3-kernel eager rewrites.** `lerp` factorization, pulling 1.25 out, `addcmul` coefficient tricks —
  all still cost 2 `addcmul` + 1 `relu`. They buy nothing and each rewrite re-risks a coefficient error
  exactly like candidate-03's.
- **Caching keyed on `data_ptr`.** Inputs are rebuilt per case; such keys are fragile and grow unbounded.
- **`torch.compile`.** Would fuse to 1 kernel, but adds first-call compile cost and its
  `reduce-overhead` mode reintroduces CUDA graphs. Out of scope for a bounded Diff.

## 5. Next round instruction

Submit **exactly one** bounded Diff to `run.py`: the 3-kernel eager rewrite in section 4(1) — no graph
machinery, no module-level mutable state beyond the two cached `(1,1)` constants. Verify the affine
coefficients by hand (1.25 on `x`, 0.75 on `y`, -0.125 bias) before submitting. Then stop; there is no
further headroom in eager PyTorch.
