import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Bias constant is a cheap host-side scalar; one device tensor is reused per
# (device, dtype) so the hot path never has to materialise it again.
_BIAS = {}

def _bias_like(x):
    key = (x.device, x.dtype)
    bias = _BIAS.get(key)
    if bias is None:
        bias = torch.tensor(-0.125, device=key[0], dtype=key[1])
        _BIAS[key] = bias
    return bias

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if not x.is_cuda:
        return reference(inputs)
    # 1.25*x + 0.75*y - 0.125 == 1.25*(x + 0.6*y) - 0.125
    # 3 device kernels total, one intermediate allocation, no clone:
    #   k1: x + 0.6*y      (addcmul)
    #   k2: 1.25*t - 0.125 (add with alpha, broadcast bias)
    #   k3: relu in place
    value = torch.addcmul(x, y, 0.6)
    value = torch.add(_bias_like(value), value, alpha=1.25)
    return torch.relu_(value)
