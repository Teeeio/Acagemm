import torch

# ---------------------------------------------------------------------------
# generic_affine (FP32):  relu(x * 1.25 + y * 0.75 - 0.125)
#
# Optimization direction (round 2): the operator is tiny (32x256 = 8192
# elements) so p50 latency is dominated by per-op Python/dispatch + kernel
# launch cost, not by arithmetic.  Two changes, both bounded to this file:
#   1. The whole expression is evaluated with 3 launch-cheap aten calls
#      (addcmul / addcmul / relu_) instead of 5 separate mul/mul/add/sub/relu
#      calls, using broadcast (1,1) constants so no per-shape setup is needed.
#   2. A lazily captured CUDA graph replays that exact chain in one launch for
#      the steady state (the benchmark re-uses the same input tensors), which
#      removes the remaining per-op dispatch cost.
# Both paths evaluate the identical expression; results match `reference`
# within the 1e-5 tolerance.  Captures are bounded; any capture failure or
# cache overflow permanently falls back to the eager 3-kernel path.
# ---------------------------------------------------------------------------

_SCALE_X = 1.25
_SCALE_Y = 0.75
_BIAS = 0.125

_CONST_CACHE = {}
_GRAPH_CACHE = {}
_MAX_GRAPH_ENTRIES = 16
_GRAPH_MODE_OK = True


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _consts(x):
    """Broadcast constants (-0.125 and 1) cached per (device, dtype)."""
    key = (x.device, x.dtype)
    cached = _CONST_CACHE.get(key)
    if cached is None:
        cached = (
            torch.full((1, 1), -_BIAS, device=x.device, dtype=x.dtype),
            torch.ones((1, 1), device=x.device, dtype=x.dtype),
        )
        _CONST_CACHE[key] = cached
    return cached


def _affine_relu(x, y):
    """relu(1.25*x + 0.75*y - 0.125) in three elementwise launches."""
    bias, ones = _consts(x)
    out = torch.addcmul(bias, x, ones, _SCALE_X)   # 1.25*x - 0.125
    out = torch.addcmul(out, y, ones, _SCALE_Y)    # + 0.75*y
    return torch.relu_(out)                        # in place, no extra alloc


def _graph_key(x, y):
    return (x.data_ptr(), y.data_ptr(),
            tuple(x.shape), tuple(x.stride()),
            tuple(y.shape), tuple(y.stride()),
            x.dtype, x.device.index)


def _capture(x, y, key):
    """Capture the affine chain into a CUDA graph; return (graph, out) or None."""
    global _GRAPH_MODE_OK
    if not _GRAPH_MODE_OK:
        return None
    if len(_GRAPH_CACHE) >= _MAX_GRAPH_ENTRIES:
        # Inputs are not being re-used; stop paying capture cost.
        _GRAPH_MODE_OK = False
        return None
    try:
        _consts(x)  # allocate constants before capture, never inside it
        warm = torch.cuda.Stream()
        warm.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(warm):
            for _ in range(3):
                _affine_relu(x, y)
        torch.cuda.current_stream().wait_stream(warm)

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out = _affine_relu(x, y)
    except Exception:
        _GRAPH_MODE_OK = False
        return None

    entry = (graph, out)
    _GRAPH_CACHE[key] = entry
    return entry


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if not (_GRAPH_MODE_OK and x.is_cuda and y.is_cuda):
        return _affine_relu(x, y)
    try:
        key = _graph_key(x, y)
    except Exception:
        return _affine_relu(x, y)

    entry = _GRAPH_CACHE.get(key)
    if entry is None:
        entry = _capture(x, y, key)
        if entry is None:
            return _affine_relu(x, y)

    graph, out = entry
    try:
        graph.replay()
    except Exception:
        _GRAPH_MODE_OK = False
        return _affine_relu(x, y)
    return out
