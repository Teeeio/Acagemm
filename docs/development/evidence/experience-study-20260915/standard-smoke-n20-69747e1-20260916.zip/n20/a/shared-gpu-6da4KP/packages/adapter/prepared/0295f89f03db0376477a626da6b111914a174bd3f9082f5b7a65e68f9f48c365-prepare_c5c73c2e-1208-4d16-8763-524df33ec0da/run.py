import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


# ---------------------------------------------------------------------------
# All mutable state lives in one module-level dict. Nothing is ever read from a
# bare module global that a function also assigns, so no name can be missing.
# ---------------------------------------------------------------------------
_STATE = {
    'graph_disabled': False,   # set once the graph path proves unusable
    'graph_cache': {},         # key -> {'graph', 'out', 'x', 'y'}
    'consts': {},              # (value, device, index, dtype) -> (1, 1) tensor
}
_GRAPH_MAX_ENTRIES = 16


def _const(value, like):
    key = (value, like.device.type, like.device.index, like.dtype)
    cached = _STATE['consts'].get(key)
    if cached is None:
        cached = torch.tensor(value, dtype=like.dtype, device=like.device).reshape(1, 1)
        _STATE['consts'][key] = cached
    return cached


def _affine_relu(x, y):
    """1.25*x + 0.75*y - 0.125 followed by relu, as 3 kernels, 1 allocation."""
    scaled = torch.addcmul(x, y, _const(0.75, x))          # x + 0.75*y
    shifted = torch.addcmul(_const(-0.125, x), scaled, _const(1.25, x))  # -0.125 + 1.25*scaled
    return torch.relu_(shifted)                            # in place, no extra buffer


def _eager(x, y):
    return _affine_relu(x, y)


def _graph_key(x, y):
    return (x.data_ptr(), y.data_ptr(),
            tuple(x.shape), tuple(y.shape),
            tuple(x.stride()), tuple(y.stride()),
            x.dtype, x.device.index)


def _graph_replay(x, y):
    """Return the graphed output for (x, y), or None if the graph path is off."""
    if _STATE['graph_disabled']:
        return None
    if not x.is_cuda or not y.is_cuda:
        return None
    try:
        if torch.cuda.is_current_stream_capturing():
            return None
    except Exception:
        return None

    cache = _STATE['graph_cache']
    key = _graph_key(x, y)
    entry = cache.get(key)
    if entry is not None:
        try:
            entry['graph'].replay()
            return entry['out']
        except Exception:
            _STATE['graph_disabled'] = True
            return None

    if len(cache) >= _GRAPH_MAX_ENTRIES:
        _STATE['graph_disabled'] = True
        return None

    try:
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                _eager(x, y)
        torch.cuda.current_stream().wait_stream(side)

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out = _eager(x, y)
        graph.replay()
        # Hold strong references to x/y so their storage cannot be recycled
        # into a different tensor that would alias this key.
        cache[key] = {'graph': graph, 'out': out, 'x': x, 'y': y}
        return out
    except Exception:
        _STATE['graph_disabled'] = True
        try:
            torch.cuda.synchronize()
        except Exception:
            pass
        return None


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    out = _graph_replay(x, y)
    if out is not None:
        return out
    return _eager(x, y)
