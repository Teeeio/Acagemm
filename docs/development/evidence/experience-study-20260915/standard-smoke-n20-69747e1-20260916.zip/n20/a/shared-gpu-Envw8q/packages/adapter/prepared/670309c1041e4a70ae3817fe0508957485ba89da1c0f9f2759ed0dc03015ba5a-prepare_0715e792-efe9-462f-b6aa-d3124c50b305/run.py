import torch

# Device-side affine constants, created once per (device, dtype) and reused.
# Keeping them as cached 0-dim tensors means the coefficient/bias scalars cost
# zero extra kernel launches (and zero allocations) on the hot path.
_CONSTANTS = {}


def _affine_constants(like):
    key = (like.device, like.dtype)
    consts = _CONSTANTS.get(key)
    if consts is None:
        consts = (
            torch.tensor(-0.125, device=like.device, dtype=like.dtype),
            torch.tensor(1.25, device=like.device, dtype=like.dtype),
            torch.tensor(0.75, device=like.device, dtype=like.dtype),
        )
        _CONSTANTS[key] = consts
    return consts


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Same math as reference(), issued as 3 device kernels instead of 5:
    #   1) out = torch.addcmul(-0.125, x, 1.25)  ->  out = 1.25 * x - 0.125
    #      (the x-scale and the bias are folded into one fused kernel, into a
    #       fresh output allocation owned by run())
    #   2) out.addcmul_(y, 0.75)                 ->  out += 0.75 * y
    #   3) out.relu_()                           ->  in-place, returns `out` itself
    # `x` and `y` are only read, never written, and the returned tensor is a
    # fresh allocation, so no defensive .clone() is needed.
    x = inputs['x']
    y = inputs['y']
    bias, scale_x, scale_y = _affine_constants(x)
    out = torch.addcmul(bias, x, scale_x)
    out.addcmul_(y, scale_y)
    return out.relu_()
