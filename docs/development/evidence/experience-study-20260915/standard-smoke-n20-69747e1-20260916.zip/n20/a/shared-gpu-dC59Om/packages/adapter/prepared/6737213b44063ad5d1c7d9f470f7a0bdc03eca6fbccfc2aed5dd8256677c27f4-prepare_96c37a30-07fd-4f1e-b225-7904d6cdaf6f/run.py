import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# ---------------------------------------------------------------------------
# run(inputs) optimization: 3 device kernels instead of 5.
#
# The baseline computes relu(x * 1.25 + y * 0.75 - 0.125) with five kernels
# (mul, mul, sub-add, relu, clone). The same value is obtained here with three
# launches by folding generic constants into fused ATen entry points:
#
#   u = torch.add(x, y, alpha=0.6)     # 1 kernel: u = x + 0.6 * y
#   u.clamp_min_(0.1)                  # 1 kernel: in-place, reuses u's storage
#   torch.addcmul(bias, u, scale)      # 1 kernel: 1.25 * u - 0.125
#
# Algebra (exact in real arithmetic; identical up to fp32 rounding of the
# scalar 0.6, ~1e-7, vs the contract atol/rtol of 1e-5):
#   1.25 > 0  =>  1.25 * relu(v) == relu(1.25 * v)
#   clamp_min(u, 0.1) == relu(u - 0.1) + 0.1
#   => 1.25 * clamp_min(u, 0.1) - 0.125 == 1.25 * relu(u - 0.1)
#                                      == relu(1.25 * u - 0.125)
#   with u = x + 0.6y  =>  1.25u - 0.125 == 1.25x + 0.75y - 0.125.
#
# No input tensor is mutated: the single in-place step operates on `u`, a
# temporary freshly allocated by torch.add. Device/dtype/shape handling and the
# zero-dim broadcast constants are resolved once and cached per device.
# ---------------------------------------------------------------------------

_DEVICE_CONSTS = {}


def _consts(device):
    consts = _DEVICE_CONSTS.get(device)
    if consts is None:
        consts = (
            torch.tensor(-0.125, dtype=torch.float32, device=device),
            torch.tensor(1.25, dtype=torch.float32, device=device),
        )
        _DEVICE_CONSTS[device] = consts
    return consts


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    u = torch.add(x, y, alpha=0.6)
    u.clamp_min_(0.1)
    bias, scale = _consts(u.device)
    return torch.addcmul(bias, u, scale)
