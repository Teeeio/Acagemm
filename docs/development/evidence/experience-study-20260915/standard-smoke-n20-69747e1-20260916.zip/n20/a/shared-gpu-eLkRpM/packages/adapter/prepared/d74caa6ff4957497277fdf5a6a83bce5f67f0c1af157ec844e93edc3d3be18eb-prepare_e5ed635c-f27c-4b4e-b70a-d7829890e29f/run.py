import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_SCALARS = {}

def _scalars(device, dtype):
    # Cache the two affine constants so the hot path never allocates/h2d-copies them.
    key = (str(device), dtype)
    cached = _SCALARS.get(key)
    if cached is None:
        cached = (
            torch.ones((), device=device, dtype=dtype),
            torch.full((), -0.125, device=device, dtype=dtype),
        )
        _SCALARS[key] = cached
    return cached

def run(inputs):
    # Fast path: fuse the affine expression into two broadcasting FMA kernels plus an
    # in-place ReLU, and drop the redundant output copy of the baseline.
    x = inputs['x']
    y = inputs['y']
    if x.is_cuda and x.dtype == torch.float32 and not (x.requires_grad or y.requires_grad):
        ones, bias = _scalars(x.device, x.dtype)
        value = torch.addcmul(bias, x, ones, value=1.25)   # 1.25 * x - 0.125
        value = torch.addcmul(value, y, ones, value=0.75)  # + 0.75 * y
        return value.relu_()
    return torch.relu(x * 1.25 + y * 0.75 - 0.125)
