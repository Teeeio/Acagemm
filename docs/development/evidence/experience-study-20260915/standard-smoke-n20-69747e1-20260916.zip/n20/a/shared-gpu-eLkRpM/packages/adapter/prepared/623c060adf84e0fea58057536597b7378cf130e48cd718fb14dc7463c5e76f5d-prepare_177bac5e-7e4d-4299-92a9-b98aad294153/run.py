import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# 0-dim (scalar) CUDA tensors broadcast against any shape, so no full-size
# constant tensor (torch.ones_like / a bias tensor) is ever materialised or
# read.  Cached per (device, dtype) and built lazily on first use.
_SCALARS = {}


def _scalars_for(device, dtype):
    key = (device, dtype)
    cached = _SCALARS.get(key)
    if cached is None:
        cached = (
            torch.tensor(-0.125, device=device, dtype=dtype),
            torch.tensor(0.75, device=device, dtype=dtype),
            torch.tensor(1.0, device=device, dtype=dtype),
        )
        _SCALARS[key] = cached
    return cached


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if x.is_cuda and x.dtype == torch.float32 and not x.requires_grad and not y.requires_grad:
        # 3 launches, 1 allocation, no redundant copy:
        #   out  = 0.75 * y - 0.125   (addcmul fuses mul+add, result allocated once)
        #   out += 1.25 * x           (in-place add with alpha)
        #   out  = relu(out)          (in-place)
        bias, w_y, one = _scalars_for(x.device, x.dtype)
        out = torch.addcmul(bias, y, one, value=0.75)
        out.add_(x, alpha=1.25)
        return out.relu_()
    return torch.relu(x * 1.25 + y * 0.75 - 0.125)
