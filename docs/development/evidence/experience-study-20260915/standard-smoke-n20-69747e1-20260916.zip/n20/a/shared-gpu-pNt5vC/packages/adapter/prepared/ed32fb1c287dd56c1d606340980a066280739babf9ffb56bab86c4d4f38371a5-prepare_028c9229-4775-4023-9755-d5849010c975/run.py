import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    # Kernel 1: 1.25 * x - 0.125 in one elementwise launch. Passing the scalar first
    # makes alpha scale the tensor operand (result = scalar + alpha * x), so the
    # leading multiply and the trailing bias collapse into a single kernel.
    out = torch.add(-0.125, x, alpha=1.25)
    # Kernel 2: fold the y term in place (out += 0.75 * y), no extra allocation.
    # Kernel 3: ReLU in place on the same buffer.
    # 3 launches total, one fresh buffer, no redundant copy.
    return out.add_(y, alpha=0.75).relu_()
