import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Single-shot elementwise affine + ReLU.
    # Removed the redundant .clone() (it was a pure device-to-device copy of a
    # freshly produced tensor) and replaced the chain of temporary allocations
    # with one output buffer reused by in-place, kernel-fused steps:
    #   out = 1.25 * x
    #   out = out + 0.75 * y
    #   out = out - 0.125
    #   out = relu(out)
    # Kernel count drops from 6 (4 temporaries + relu + clone) to 4, and only a
    # single allocation is made.
    x = inputs['x']
    y = inputs['y']

    if x.shape != y.shape:
        # Preserve numpy/PyTorch broadcasting semantics of the reference.
        x, y = torch.broadcast_tensors(x, y)

    out = torch.mul(x, 1.25)
    torch.add(out, y, alpha=0.75, out=out)
    out.sub_(0.125)
    torch.relu_(out)
    return out
