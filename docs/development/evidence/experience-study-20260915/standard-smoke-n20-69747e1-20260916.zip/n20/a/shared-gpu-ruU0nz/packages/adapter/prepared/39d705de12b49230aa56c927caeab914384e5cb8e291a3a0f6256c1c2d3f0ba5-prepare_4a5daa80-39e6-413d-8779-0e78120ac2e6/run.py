import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_SCALE_X = 1.25
_SCALE_Y = 0.75
_SHIFT = -0.125

# 0-dim scalars are cached per (device, dtype) so no host->device copy and no
# extra allocation happen on the hot path.
_CONSTANTS = {}


def _constants(ref):
    key = (ref.device, ref.dtype)
    consts = _CONSTANTS.get(key)
    if consts is None:
        consts = (
            torch.tensor(_SHIFT, device=ref.device, dtype=ref.dtype),
            torch.tensor(_SCALE_X, device=ref.device, dtype=ref.dtype),
        )
        _CONSTANTS[key] = consts
    return consts


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    shift, scale_x = _constants(x)
    # Fused bias + scale: out = 1.25 * x - 0.125 in a single elementwise kernel.
    out = torch.addcmul(shift, x, scale_x)
    # Scale-and-accumulate the second operand in place: out += 0.75 * y.
    out.add_(y, alpha=_SCALE_Y)
    # ReLU in place; `out` is a freshly allocated buffer, inputs are never mutated.
    out.clamp_min_(0.0)
    return out
