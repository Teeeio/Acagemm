import hashlib
import json
from pathlib import Path
import zipfile
from datetime import datetime, timezone

root = Path.cwd()
local = root / '.operator-studio-local'
evidence = root / 'docs/development/evidence/experience-study-20260915'
sha = lambda data: hashlib.sha256(data).hexdigest()
source = json.loads((local / 'runner-status-repair-source.json').read_text(encoding='utf-8'))
for item in source['files']:
    assert sha((root / item['path']).read_bytes()) == item['sha256'], item['path']
assert json.loads((local / 'runner-status-repair-full-exit.json').read_text(encoding='utf-8-sig'))['exitCode'] == 0
log = (local / 'runner-status-repair-full.log').read_text(encoding='utf-8-sig')
assert '[release-check] PASS: 149 checks completed' in log
assert '[non-hardware-check] PASS: 44 checks completed without physical hardware' in log
assert 'real Windows short/permanent locks and atomic status passed' in log
names = ['probe-runner-status-lock.py', 'runner-status-lock-reproduction.json', 'runner-status-repair-source.json', 'runner-status-repair-tests.log', 'runner-status-repair-full.log', 'runner-status-repair-full-exit.json', 'archive-runner-status-repair.py']
archive = evidence / 'runner-status-write-repair-20260916.zip'
assert not archive.exists()
entries = [(name, (local / name).read_bytes()) for name in names]
entries += [('source/' + item['path'], (root / item['path']).read_bytes()) for item in source['files']]
manifest = [{'path': name, 'sha256': sha(data), 'bytes': len(data)} for name, data in entries]
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in entries:
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        assert sha(z.read(item['path'])) == item['sha256']
p = evidence / 'status.json'
status = json.loads(p.read_text(encoding='utf-8'))
status['runnerStatusWriteRepair'] = {
    'id': 'R6-Windows-atomic-runner-progress-write',
    'status': 'software_verified_new_live_batch_pending',
    'execution': 'primary_agent_direct_user_authorized',
    'dispatchTaskId': None,
    'fact': 'R6 retained WinError 5 replacing runner-status.json; queue reported SHARED_GPU_RUNNER_FAILED, confirmed release, and no execution experience for that infrastructure failure. An isolated real Windows handle denying FILE_SHARE_DELETE reproduced WinError 5 and preserved the old JSON. The base progress writer now retries only Windows errors 5/32/33 for up to one monotonic second, with at most 25ms sleeps. Success still requires atomic replacement; persistent or other errors propagate. Task, Agent, Mission, collection and correctness budgets are unchanged.',
    'inference': 'A short-lived reader handle is sufficient to cause the observed failure mechanism. The bounded retry lets a released handle stop blocking progress publication without accepting partial JSON or fabricating success.',
    'unknown': 'The actual owner/duration of the historical denied handle is unknown. This does not prove every WinError 5 is transient or fix the thinking-only model run. No new live run is yet included in this repair entry.',
    'evidence': ['direct-study-r6-12a3c2a-20260916.zip', archive.name],
    'next_action': 'Commit the repaired source; freeze its new identity and start a new nine-slot live study. Retain R6 as failed/noncomparable, never top it up or count it as N20.',
    'source': source,
    'checks': [
        {'command': 'python tests/local-c500-runner-contract-test.py', 'exitCode': 0, 'scope': 'Existing matrix assertions, real short/permanent Windows handles and unclassified-error propagation'},
        {'command': 'npm run verify:non-hardware-robustness', 'exitCode': 0, 'passedChecks': 44, 'includedReleaseChecks': 149},
    ],
    'archive': {'path': archive.name, 'sha256': sha(archive.read_bytes()), 'files': manifest, 'crcAndHashesVerified': True},
    'platformContextSyncPending': True,
}
status['updatedAt'] = datetime.now(timezone.utc).isoformat()
status['status'] = 'r6-retained-windows-status-write-repair-verified-new-live-pending'
p.write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(manifest), 'sha256': sha(archive.read_bytes()), 'status': status['status']}))
