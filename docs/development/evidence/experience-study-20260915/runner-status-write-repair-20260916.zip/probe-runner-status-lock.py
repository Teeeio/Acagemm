import ctypes
from ctypes import wintypes
import importlib.util
import json
from pathlib import Path
import tempfile

root = Path.cwd()
spec = importlib.util.spec_from_file_location('runner', root / 'tools/local-c500-runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
directory = Path(tempfile.mkdtemp(prefix='runner-status-lock-', dir=root / '.operator-studio-local'))
runner._write_runner_status(directory, 10, 'before', 'old complete status')
target = directory / 'runner-status.json'
before = target.read_bytes()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
kernel.CreateFileW.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.CloseHandle.restype = wintypes.BOOL
handle = kernel.CreateFileW(str(target), 0x80000000, 3, None, 3, 128, None)
if handle == ctypes.c_void_p(-1).value:
    raise ctypes.WinError(ctypes.get_last_error())
try:
    try:
        runner._write_runner_status(directory, 20, 'after', 'new complete status')
    except PermissionError as error:
        result = {'reproduced': True, 'winerror': error.winerror, 'oldRecordUnchanged': target.read_bytes() == before}
    else:
        raise AssertionError('Expected the destination handle to deny atomic replacement')
finally:
    assert kernel.CloseHandle(handle)
runner._write_runner_status(directory, 20, 'after', 'new complete status')
result['succeedsAfterHandleRelease'] = json.loads(target.read_text(encoding='utf-8'))['progress'] == 20
result['scope'] = 'Isolated reproduction with our own Windows handle denying FILE_SHARE_DELETE; no GPU/model invocation. Does not identify the historical handle owner.'
(root / '.operator-studio-local/runner-status-lock-reproduction.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
