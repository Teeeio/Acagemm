import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Cached 0-dim tensor used to fold the affine tail into a single fused kernel.
# Keyed by (device, dtype); created lazily on first use, never mutated.
_AFFINE_END_CACHE = {}

def run(inputs):
    x = inputs['x']
    y = inputs['y']

    # 1.25*x + 0.75*y - 0.125 == 1.25*(x + 0.6*y) - 0.125
    # k1: fused scale-add  -> u = x + 0.6*y
    out = torch.add(x, y, alpha=0.6)

    # k2: lerp_ with end=0.5, weight=-0.25 computes u + (-0.25)*(0.5 - u)
    #     == 1.25*u - 0.125, i.e. the 1.25 scaling AND the bias in one kernel.
    key = (x.device, x.dtype)
    end = _AFFINE_END_CACHE.get(key)
    if end is None:
        end = torch.tensor(0.5, device=x.device, dtype=x.dtype)
        _AFFINE_END_CACHE[key] = end
    out.lerp_(end, -0.25)

    # k3: relu in place.
    out.relu_()
    return out
