# MIS_MU2OKOFN — affine generic GPU iteration — direction assessment (round 01)

## Acquisition result

- Local Source Registry: `.operator-studio/source-registry.json` = `{"schemaVersion": 2, "sources": []}` — **empty**.
- Source Registry root `projects/affine/sources`: **no child directories** (glob and grep both return nothing).
- => `semanticFallback: true`. See the returned JSON `fallbackReason` for the baseline spec handed to the Materializer.

Why no remote Git source is selected, despite the network option:

1. The execution adapter is `python-shared-gpu`, `languages: ["python"]`, `build: {}` (from `artifacts/MIS_MU2OKOFN/test-result.json` -> `environment.executionPackage.adapter`). A C++/CUDA kernel repository could not be compiled or materialized by this adapter even if cloned.
2. The operator is a single elementwise expression whose entire fixed contract (`inputs_for`, `get_inputs`, `get_test_cases`, `get_benchmark_inputs`, `reference`) is already embedded verbatim in the Mission's `run.py`. No external repository can supply a better baseline than the Mission itself.
3. The Mission explicitly forbids network use; cloning a repo that cannot improve the artifact would violate that constraint for zero benefit.

## Evidence base (recorded artifacts, read-only)

`artifacts/MIS_MU2OKOFN/test-result.json` (candidate-02, digest `sha256:3caa539dcbbc22ee137f11b55a044555237985985f2b7786551b13151360023d`):

| field | value |
|---|---|
| correctness | **passed**, 4/4 (minimal, representative, boundary, ragged) |
| maxDiff | 0 / 9.5367431640625e-7 / 9.5367431640625e-7 / 9.5367431640625e-7 |
| latency p50 (primary) | **9.216 us** |
| referenceValue | **15.36 us** |
| speedup | **1.6667x** |
| p95 | 10.24 us |
| samples / warmup | 10 / 3 |

Hardware: `NVIDIA GeForce RTX 3060 Laptop GPU`, sm86, 6 GiB, driver 551.78, torch 2.6.0+cu124, CUDA 12.4.
`tracer.json` and `profiler.json` are both `status: unavailable` (`mctracer`/`mcProfiler` not installed) — no per-kernel timeline exists, so all inference below is from the latency deltas, not from a profile. This is stated as inference, not as measured fact.

Both benchmark profiles (`primary` 32x256 and `small` 2x32) report **identical** values (9.216 / 15.36). Shape does not move the number at all => the measured quantity is host dispatch + graph-launch + measurement overhead, not GPU work in either direction.

## Diagnosis of the candidate-03 failure

`workspace/MIS_MU2OKOFN/repository/run.py` (candidate-03) is candidate-02's proven structure plus a one-line change:

```python
out = torch.add(x, y, alpha=0.6)      # x + 0.6y
out.lerp_(0.5, -0.25)                 # <- TypeError
out.relu_()
```

`Tensor.lerp_(end, weight)` requires `end` to be a **Tensor**. Passing `0.5` as a float produces exactly the recorded error:

```
lerp_() received an invalid combination of arguments - got (float, float) ...
  * (Tensor end, Tensor weight) ... some of the arguments have invalid types: (!float!, !float!)
  * (Tensor end, Number weight) ... some of the arguments have invalid types: (!float!, !float!)
```

The identity itself is correct: `lerp_(end=0.5, w=-0.25)` = `1.25*self - 0.125`, and `relu(1.25u - 0.125) == 1.25*max(u, 0.1) - 0.125` since `1.25 > 0`. **The failure is a signature bug in one call, not a dead end** — and because `run()` raises, the whole candidate is reported as `OPERATOR_CANDIDATE_EXCEPTION`. It also silently discarded the already-working graph path.

## Verdict: CONTINUE the direction, with a different mechanism

Reason: the launch-count-reduction family is the only direction with **measured positive yield**, and it is converging, not stalling:

- eager 3-launch: 15.36 us
- graph-replayed 3-launch: 9.216 us
- delta 6.144 us over 2 eliminated launches = **~3.07 us saved per eliminated launch**

That per-launch figure is the useful constant here. It says host launch overhead dominates and that further host-side micro-optimization is still on the critical path — the opposite of a saturated direction.

### (1) Highest-ROI next diff — dispatch-only identity fast path (new mechanism, not a retry of the failed one)

Per-call cost currently paid before the replay even starts:

```python
if (not _GRAPH_ENABLED) or (not x.is_cuda) or x.shape != y.shape or _is_capturing(): ...
key = (x.data_ptr(), y.data_ptr(), x.shape, x.stride(), x.dtype, x.device)
entry = _GRAPHS.get(key)
```

`x.data_ptr()`, `x.stride()`, `x.dtype`, `x.device` are C++ round-trips and the tuple of `torch.Size`/`torch.dtype`/`torch.device` objects must be hashed — order 2-4 us of pure Python per call, against a 9.216 us total. Replacing it with an identity compare on the hot path is essentially free:

```python
_FAST = None  # (x, y, graph, out)
def run(inputs):
    x = inputs['x']; y = inputs['y']
    f = _FAST
    if f is not None and x is f[0] and y is f[1]:
        f[2].replay()
        return f[3]
    ... existing keyed path unchanged; set _FAST when a graph is built ...
```

Why this is safe and worth the round:

- It leaves the arithmetic **bit-identical** — it is the same graph, replayed. The correctness margin is already thin (maxDiff 9.5367e-7 = 2^-20 against the oracle), so a purely dispatch-level diff is the only class of change that cannot erode it.
- candidate-02's graph hit proves the same buffers recur across benchmark iterations (its key is address/shape/stride/dtype/device based). An `is` check on the same tensors will hit on the same calls.
- Misses are harmless: any non-identical call falls through to the existing keyed path and then to eager, so the correctness cases (single-shot, distinct tensors) still never touch the graph.
- It also skips `torch.cuda.is_current_stream_capturing()` on the hot path; if that is judged too aggressive, keep the probe first — the key construction is the larger cost either way.

Second-order, same family, lower confidence: fold the rank-2 `check` chain (`x.is_cuda`, `x.shape != y.shape`) behind the identity fast path so the hit path is one `is`, one `replay()`, one return.

### (2) Stop-investing list (low ROI / traps)

- **Vectorization.** The Mission itself marks this unverified; do not claim a bandwidth bound. At 32x256 FP32 the tensors are 32 KB, both benchmark profiles measure identically, and the quantity being measured is host overhead — vectorizing an elementwise kernel cannot move it. It is also not expressible in pure PyTorch without a custom extension, and the adapter is python-only with `build: {}`. Same family as float4/float2 reinterpret tricks: unbuildable here.
- **`torch.compile`.** Four distinct shapes (1x1, 32x256, 2x32, 3x17) plus per-call guard evaluation would cost more than the ~3 us launch it could remove, and the first-call compile cost lands inside the measured region.
- **Further 3-kernel reformulations** (`mul_`/`sub_`/`lerp_`/`clamp_min`/`addcmul` swaps). Strictly dominated by candidate-02's graph path, which already collapses the same three kernels to one launch. This is the trap the last round fell into — it re-derived equivalent math and lost the working path. Do not spend another candidate here.
- **Chasing the literal target.** "99.9999% improvement" over 15.36 us requires p50 ~1.5e-11 us (~15 attoseconds). That is unreachable at any implementation quality; the honest objective is to maximise speedup against the 15.36 us reference, which is what the recorded 1.6667x already does.

### Note for whichever diff is submitted next

Restore candidate-02's working lerp-free body (`add(alpha=0.6)` -> `relu_` with the scale/shift folded, or the two-op `mul_`/`sub_` form) **before** layering the fast path, so the submission cannot regress the proven 1.6667x. If the `lerp_` fusion is kept at all, `end` must be a Tensor (e.g. a module-level `_LERP_END_T = torch.tensor(0.5, device=..., dtype=...)`), but it buys nothing over candidate-02 and is not recommended.
