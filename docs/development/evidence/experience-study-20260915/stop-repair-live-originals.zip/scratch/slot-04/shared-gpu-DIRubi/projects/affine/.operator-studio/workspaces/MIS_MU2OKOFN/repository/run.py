import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# ---------------------------------------------------------------------------
# run(inputs) implementation under test.
#
# 1.25*x + 0.75*y - 0.125  ==  1.25*(x + 0.6*y) - 0.125
#
# so the whole operator is one allocation and three launches:
#   torch.add(x, y, alpha=0.6) -> x + 0.6*y
#   out.lerp_(end, -0.25)      -> out + (-0.25)*(0.5 - out) = 1.25*out - 0.125
#   out.relu_()                -> relu(...)
# The baseline spends five launches (mul, mul, add, sub, relu) plus a
# redundant .clone() device copy on the same 32x256 tensor.
# NOTE: lerp_ only accepts (Tensor end, Tensor weight) / (Tensor end, Number
# weight); a Number end is rejected, so the 0.5 endpoint is held as a cached
# 0-dim tensor.
# ---------------------------------------------------------------------------

_SCALAR_ENDPOINTS = {}


def _affine_relu(x, y):
    out = torch.add(x, y, alpha=0.6)
    device = out.device
    end = _SCALAR_ENDPOINTS.get(device)
    if end is None or end.dtype != out.dtype:
        end = torch.tensor(0.5, dtype=out.dtype, device=device)
        _SCALAR_ENDPOINTS[device] = end
    out.lerp_(end, -0.25)
    return out.relu_()


# --- optional replay fast path -------------------------------------------
# The benchmark re-uses the same two input buffers for every timed call, so
# the three launches above can be captured once and replayed with a single
# cudaGraphLaunch. The cache keeps strong references to the captured x/y so
# their addresses can never be recycled by the caching allocator, and every
# failure path falls back to the eager three-launch result computed above.

_GRAPH_ENABLED = hasattr(torch.cuda, 'CUDAGraph')
_GRAPH_CACHE = {}
_GRAPH_LIMIT = 8
_IS_CAPTURING = getattr(torch.cuda, 'is_current_stream_capturing', None)


def _capture(x, y):
    graph = torch.cuda.CUDAGraph()
    side = torch.cuda.Stream()
    side.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side):
        for _ in range(3):
            _affine_relu(x, y)
    torch.cuda.current_stream().wait_stream(side)
    torch.cuda.synchronize()
    with torch.cuda.stream(side):
        graph.capture_begin()
        try:
            out = _affine_relu(x, y)
        finally:
            graph.capture_end()
    return graph, out


def run(inputs):
    global _GRAPH_ENABLED
    x = inputs['x']
    y = inputs['y']
    if _GRAPH_ENABLED:
        key = (x.data_ptr(), y.data_ptr())
        entry = _GRAPH_CACHE.get(key)
        if entry is not None:
            if entry[2] is x and entry[3] is y:
                entry[0].replay()
                return entry[1]
        elif (x.is_cuda and y.is_cuda
                and len(_GRAPH_CACHE) < _GRAPH_LIMIT
                and (_IS_CAPTURING is None or not _IS_CAPTURING())):
            result = _affine_relu(x, y)
            try:
                graph, out = _capture(x, y)
            except Exception:
                _GRAPH_ENABLED = False
                return result
            _GRAPH_CACHE[key] = (graph, out, x, y)
            return result
    return _affine_relu(x, y)
