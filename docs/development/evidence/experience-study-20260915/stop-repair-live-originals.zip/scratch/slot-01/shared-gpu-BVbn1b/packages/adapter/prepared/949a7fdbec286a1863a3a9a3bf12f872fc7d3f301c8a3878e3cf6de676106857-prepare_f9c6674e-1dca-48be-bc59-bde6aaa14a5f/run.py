import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # One allocation + 4 in-place elementwise kernels.
    # Baseline issued 5 out-of-place kernels plus a redundant .clone() (6 launches,
    # 6 allocations) for a result that is dead immediately after being returned.
    # The arithmetic order is kept identical to reference(); the only deviation is that
    # add_(alpha=) may contract to FMA, i.e. <= 1 ulp (~1e-7 at |v|<=10), which is far
    # inside the 1e-5 atol/rtol. Inputs are never modified in place, so repeated
    # benchmark repeats and the correctness oracle stay valid.
    out = torch.mul(inputs['x'], 1.25)
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    return torch.relu_(out)
