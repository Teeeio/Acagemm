import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Same math as reference(), expressed so that no redundant copy and no
    # per-term temporary is materialized:
    #   relu(1.25*x + 0.75*y - 0.125)
    #     = relu(1.25*(x + 0.6*y) - 0.125)          (factor 1.25 > 0, so it
    #     = 1.25*relu(x + 0.6*y - 0.1)               commutes with relu)
    #     = 1.25*clamp_min(x + 0.6*y, 0.1) - 0.125
    # One freshly allocated buffer, three fused elementwise kernels, in-place
    # afterwards; inputs are never mutated.
    out = torch.add(inputs['x'], inputs['y'], alpha=0.6)
    out.clamp_min_(0.1)
    out.add_(-0.1, alpha=1.25)
    return out
