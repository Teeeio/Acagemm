import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# The 0-dim operands below broadcast to every test shape (1x1, 2x32, 3x17, 32x256),
# so a single set of constants serves all cases.
# NOTE: torch.add(x, c, alpha=1.25) would compute x + 1.25*c -- alpha scales the
# *other* operand, so it cannot fold the bias onto the scaled x term.
_CONSTANTS = None

def run(inputs):
    global _CONSTANTS
    x = inputs['x']
    constants = _CONSTANTS
    if constants is None:
        constants = _CONSTANTS = (
            torch.tensor(-0.125, device=x.device, dtype=x.dtype),
            torch.tensor(1.0, device=x.device, dtype=x.dtype),
        )
    bias, one = constants
    # bias + 1.25 * x * one  ==  1.25*x - 0.125, fused into one elementwise kernel
    value = torch.addcmul(bias, x, one, value=1.25)
    value.add_(inputs['y'], alpha=0.75)   # in-place FMA for the y term
    return value.relu_()                  # in-place activation
