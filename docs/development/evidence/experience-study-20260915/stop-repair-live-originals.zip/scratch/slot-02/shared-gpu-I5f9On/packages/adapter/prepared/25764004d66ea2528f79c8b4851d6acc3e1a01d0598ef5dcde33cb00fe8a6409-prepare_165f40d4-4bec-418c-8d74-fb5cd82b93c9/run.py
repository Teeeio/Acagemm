import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_A = 1.25
_B = 0.75
_C = 0.125


def _affine_relu_functional(x, y):
    # Pure functional form so a pointwise backend can fuse the whole chain
    # (mul, add, sub, relu) into a single device kernel.
    return torch.relu(x * _A + y * _B - _C)


def _affine_relu_eager(x, y):
    # Exactly one allocation, then three in-place passes. Neither input is
    # written: x is read by mul (which allocates a fresh result) and y is only
    # read through the alpha-scaled add_.
    out = x.mul(_A)
    out.add_(y, alpha=_B)
    out.sub_(_C)
    return out.clamp_min_(0.0)


_compiled_fn = None
_fast_path_disabled = False


def _fast_path():
    global _compiled_fn, _fast_path_disabled
    if _compiled_fn is None and not _fast_path_disabled:
        try:
            _compiled_fn = torch.compile(_affine_relu_functional)
        except Exception:
            _fast_path_disabled = True
    return _compiled_fn


def run(inputs):
    global _compiled_fn, _fast_path_disabled
    x = inputs['x']
    y = inputs['y']
    fn = _fast_path()
    if fn is not None:
        try:
            return fn(x, y)
        except Exception:
            # Compilation or the compiled call is unsupported on this host,
            # dtype or shape: disable the fast path and serve this call eagerly.
            _compiled_fn = None
            _fast_path_disabled = True
    return _affine_relu_eager(x, y)
