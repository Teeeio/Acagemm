import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Single output allocation, then in-place chain:
    #   out = x * 1.25 ; out += 0.75 * y ; out -= 0.125 ; out = max(out, 0)
    # The baseline materialized 5 temporaries plus a redundant .clone() (6 kernels,
    # 6 allocations). This keeps the exact same math order but drops the copy and
    # every extra temporary, so only 4 kernel launches and 1 allocation remain.
    # Both inputs stay read-only; no input tensor is mutated.
    out = inputs['x'].mul(1.25)
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    out.clamp_min_(0.0)
    return out
