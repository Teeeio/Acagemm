import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Lazily created 0-dim device scalars reused by every call: they let one
# addcmul kernel carry the x term *and* the -0.125 bias (fused multiply-add),
# so the whole operator is 3 kernels instead of 6.
_UNIT = None
_BIAS = None


def run(inputs):
    global _UNIT, _BIAS
    x = inputs['x']
    if _UNIT is None or _UNIT.dtype != x.dtype or _UNIT.device != x.device:
        _UNIT = torch.ones((), dtype=x.dtype, device=x.device)
        _BIAS = torch.full((), -0.125, dtype=x.dtype, device=x.device)
    # out = -0.125 + 1.25 * x * 1.0   (input + value*t1*t2 fused in one kernel)
    out = torch.addcmul(_BIAS, x, _UNIT, value=1.25)
    out.add_(inputs['y'], alpha=0.75)  # out += 0.75 * y
    out.relu_()
    return out
