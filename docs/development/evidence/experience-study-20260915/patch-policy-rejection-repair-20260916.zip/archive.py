import hashlib, json, zipfile
from pathlib import Path
from datetime import datetime, timezone
root=Path.cwd(); local=root/'.operator-studio-local/patch-policy-repair'; evidence=root/'docs/development/evidence/experience-study-20260915'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=json.loads((local/'source.json').read_text(encoding='utf-8'))
for item in source['files']: assert sha((root/item['path']).read_bytes())==item['sha256'],item['path']
result=json.loads((local/'exit.json').read_text(encoding='utf-8-sig')); assert result['exitCode']==0
log=(local/'verification.log').read_text(encoding='utf-8-sig')
assert '[release-check] PASS: 149 checks completed' in log
assert '[non-hardware-check] PASS: 44 checks completed without physical hardware' in log
assert 'durable policy rejection, restart, model projection, stop and normal admission passed' in log
entries=[(p.name,p.read_bytes()) for p in sorted(local.iterdir()) if p.is_file()]
entries += [('source/'+item['path'],(root/item['path']).read_bytes()) for item in source['files']]
manifest=[{'path':p,'sha256':sha(b),'bytes':len(b)} for p,b in entries]
archive=evidence/'patch-policy-rejection-repair-20260916.zip'; assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p,b in entries:z.writestr(p,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in manifest: assert sha(z.read(item['path']))==item['sha256']
p=evidence/'status.json'; status=json.loads(p.read_text(encoding='utf-8'))
status['patchPolicyRejectionRepair']={
'id':'R7-policy-rejection-lost-projection','status':'software_verified_new_live_batch_pending','execution':'primary_agent_direct_user_authorized','dispatchTaskId':None,
'fact':'Automatic admission now returns the typed, effect-free PatchPolicyCheckError as a paused needs_human state. The lifecycle persists the completed Agent projection and mission/candidate/run/diff-bound policy checks together. Managed Agent observation preserves this policy control state for the same Mission/run. High risk and all existing checks still reject; unexpected failures, including journal persistence errors, still propagate.',
'inference':'The persisted pause and needs_human guard prevent the repeated preparation seen 102 times in R7 without admitting the rejected candidate.',
'unknown':'Hardware-free integration verifies the production chain with a fixture Provider and real Git/journal/snapshot files; it is not real model/GPU proof. The repair does not guarantee that the model will propose an admissible candidate or that the exploratory study or a new N20 will pass.',
'evidence':['direct-study-r7-906832a-20260916.zip',archive.name],
'next_action':'Commit and freeze the new source; run a separate nine-slot live study with original budgets, comparability and stop rules. Preserve R7 failure and old N20 source boundary.',
'source':source,'checks':[{'command':result['command'],'exitCode':0,'passedChecks':44,'includedReleaseChecks':149}],
'archive':{'path':archive.name,'sha256':sha(archive.read_bytes()),'files':manifest,'crcAndHashesVerified':True},'platformContextSyncPending':True}
status['updatedAt']=datetime.now(timezone.utc).isoformat();status['status']='r7-retained-policy-rejection-repair-verified-new-live-pending'
p.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive':archive.name,'files':len(manifest),'sha256':sha(archive.read_bytes())}))
