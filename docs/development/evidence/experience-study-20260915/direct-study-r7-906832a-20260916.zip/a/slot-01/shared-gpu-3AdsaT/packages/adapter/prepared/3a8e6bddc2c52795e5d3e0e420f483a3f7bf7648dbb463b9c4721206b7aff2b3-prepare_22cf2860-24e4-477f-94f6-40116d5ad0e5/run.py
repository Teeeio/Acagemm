import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # 1.25*x + 0.75*y - 0.125, then relu, evaluated as a single in-place chain
    # on one freshly allocated buffer.
    # - drops the redundant trailing .clone() (baseline allocated a 6th tensor
    #   and copied the whole result into it for nothing),
    # - folds the scale/offset into in-place ops so no extra intermediates are
    #   materialized: 4 elementwise kernels and 1 allocation instead of 6/6.
    # x and y are both contiguous CUDA fp32 tensors of identical shape
    # (torch.flip materializes a contiguous copy), so every elementwise access
    # is a legal, coalesced unit-stride access; the mutation target is a private
    # buffer, so inputs['x'] / inputs['y'] stay intact for reference(inputs).
    out = torch.mul(inputs['y'], 0.75)
    out.add_(inputs['x'], alpha=1.25)
    out.sub_(0.125)
    return torch.relu_(out)
