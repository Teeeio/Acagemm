import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_ADDCMUL = torch.addcmul
_RELU_ = torch.Tensor.relu_
_AFFINE_COEFFS = {}

def _affine_coeffs(x):
    # Scalar operands for the fused affine kernel, cached per (device, dtype).
    key = (x.device, x.dtype)
    coeffs = _AFFINE_COEFFS.get(key)
    if coeffs is None:
        coeffs = (torch.tensor(1.25, dtype=x.dtype, device=x.device),
                  torch.tensor(-0.125, dtype=x.dtype, device=x.device))
        _AFFINE_COEFFS[key] = coeffs
    return coeffs

def run(inputs):
    # relu(1.25*x + 0.75*y - 0.125), recomputed as relu((1.25*x - 0.125) + 0.75*y).
    # Kernel 1 also applies the constant bias, so the shift costs no extra launch.
    scale, bias = _affine_coeffs(inputs['x'])
    out = _ADDCMUL(bias, inputs['x'], scale)   # 1.25*x - 0.125, one fused kernel
    out.add_(inputs['y'], alpha=0.75)          # += 0.75*y, in place
    return _RELU_(out)                         # in-place ReLU, same buffer, no copy
