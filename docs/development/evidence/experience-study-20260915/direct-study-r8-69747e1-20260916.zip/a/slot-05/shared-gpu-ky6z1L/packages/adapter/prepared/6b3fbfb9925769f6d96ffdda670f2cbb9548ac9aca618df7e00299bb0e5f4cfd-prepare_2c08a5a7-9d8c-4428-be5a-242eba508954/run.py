import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Constant-folded, allocation-minimal elementwise chain.
    #   1.25 * x + 0.75 * y - 0.125  ==  1.25 * (x - 0.1) + 0.75 * y
    # The fold lets the very first dispatch both allocate the destination
    # buffer and apply the offset, so the chain needs only one allocation and
    # three further in-place kernels (no .clone(), no torch.empty_like).
    # inputs['x'] / inputs['y'] are only read; every call returns a fresh tensor.
    out = torch.sub(inputs['x'], 0.1)      # out = x - 0.1        (allocates)
    out.mul_(1.25)                          # out = 1.25*x - 0.125
    out.add_(inputs['y'], alpha=0.75)       # out = 1.25*x + 0.75*y - 0.125
    out.relu_()                             # out = relu(...)
    return out
