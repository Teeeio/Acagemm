import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Deliverable path: single destination buffer + fully in-place chain.
    # Removes the redundant .clone() (extra full-tensor device copy + alloc) and
    # the temporaries produced by the out-of-place expression form.
    x = inputs['x']
    y = inputs['y']
    out = torch.empty_like(x)
    # 0.75*y + 1.25*x - 0.125, evaluated in place on the single destination buffer.
    torch.mul(y, 0.75, out=out)   # out = 0.75 * y
    out.add_(x, alpha=1.25)       # out = 0.75*y + 1.25*x  (IEEE addition commutes: same rounding as reference)
    out.sub_(0.125)               # out = 0.75*y + 1.25*x - 0.125
    out.relu_()                   # relu(...)
    return out
