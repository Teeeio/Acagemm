import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_BIAS_CACHE = {}

def _bias_tensor(x):
    """Cached broadcastable constant holding -0.125 (no per-call allocation/kernel)."""
    key = (x.dtype, x.device)
    bias = _BIAS_CACHE.get(key)
    if bias is None:
        bias = torch.full((1, 1), -0.125, dtype=x.dtype, device=x.device)
        _BIAS_CACHE[key] = bias
    return bias

def run(inputs):
    # Same math as reference (1.25*x + 0.75*y - 0.125, then relu), but the
    # constant is folded into the leading add so the whole expression needs
    # 3 kernels instead of 6, and the redundant `.clone()` device copy is gone.
    x = inputs['x']
    y = inputs['y']
    out = torch.add(_bias_tensor(x), x, alpha=1.25)
    out.add_(y, alpha=0.75)
    out.clamp_min_(0)
    return out
