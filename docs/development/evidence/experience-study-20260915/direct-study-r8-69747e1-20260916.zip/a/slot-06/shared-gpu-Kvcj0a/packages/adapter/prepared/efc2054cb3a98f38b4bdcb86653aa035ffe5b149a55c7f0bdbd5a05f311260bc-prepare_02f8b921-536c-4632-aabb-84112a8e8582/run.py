import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_BIAS = {}
_GRAPH_CACHE = {}
_MAX_GRAPHS = 12
_GRAPH_DISABLED = False


def _bias_for(x):
    # -0.125 folded into the leading add, cached per (dtype, device).
    key = (x.dtype, x.device)
    bias = _BIAS.get(key)
    if bias is None:
        bias = torch.tensor(-0.125, dtype=x.dtype, device=x.device)
        _BIAS[key] = bias
    return bias


def _affine_eager(x, y):
    # 3 kernels, no redundant copy: add(alpha) -> add_(alpha) -> clamp_min_.
    out = torch.add(_bias_for(x), x, alpha=1.25)
    out.add_(y, alpha=0.75)
    out.clamp_min_(0)
    return out


def _graph_key(x, y):
    return (x.data_ptr(), y.data_ptr(), tuple(x.shape), tuple(x.stride()),
            tuple(y.shape), tuple(y.stride()), x.dtype, y.dtype, str(x.device))


def _capture(x, y):
    # Warm the allocator on a side stream first, then capture the same chain.
    graph = torch.cuda.CUDAGraph()
    side = torch.cuda.Stream()
    side.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side):
        for _ in range(3):
            torch.relu(x * 1.25 + y * 0.75 - 0.125)
    torch.cuda.current_stream().wait_stream(side)
    with torch.cuda.graph(graph, capture_error_mode='thread_local'):
        out = torch.relu(x * 1.25 + y * 0.75 - 0.125)
    return graph, out


def run(inputs):
    global _GRAPH_DISABLED
    x = inputs['x']
    y = inputs['y']
    if not _GRAPH_DISABLED and x.is_cuda and x.is_contiguous() and y.is_contiguous():
        key = _graph_key(x, y)
        entry = _GRAPH_CACHE.get(key)
        if entry is None and len(_GRAPH_CACHE) < _MAX_GRAPHS:
            try:
                entry = _capture(x, y)
            except Exception:
                # Graphs unavailable on this runner: stick to the eager path.
                _GRAPH_DISABLED = True
                entry = None
            else:
                _GRAPH_CACHE[key] = entry
        if entry is not None:
            # Replay re-reads the captured buffers, so fresh values in the same
            # input tensors are picked up without re-capturing.
            entry[0].replay()
            return entry[1]
    return _affine_eager(x, y)
