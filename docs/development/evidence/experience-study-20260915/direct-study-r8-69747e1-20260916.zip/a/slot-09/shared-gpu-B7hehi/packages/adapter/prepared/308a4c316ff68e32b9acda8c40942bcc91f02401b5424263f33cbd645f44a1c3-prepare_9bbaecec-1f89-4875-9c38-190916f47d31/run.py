import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Bounded optimization over the naive_v0 baseline:
    #   * drops the redundant trailing .clone() device copy (one full extra kernel
    #     plus one extra allocation for an 8192-element tensor), and
    #   * collapses the elementwise chain onto a single freshly allocated buffer
    #     using in-place steps, so the tiny 32x256 workload issues 4 kernels
    #     instead of 6 (x*1.25, add_, sub_, clamp_min_) with only one allocation.
    # `value` is produced by an out-of-place multiply, so it never aliases
    # inputs['x']; the in-place steps therefore cannot mutate caller inputs and
    # repeated benchmark iterations stay independent. Arithmetic order and dtype
    # are unchanged from the baseline reference expression.
    value = inputs['x'] * 1.25
    value.add_(inputs['y'], alpha=0.75)
    value.sub_(0.125)
    value.clamp_min_(0)
    return value
