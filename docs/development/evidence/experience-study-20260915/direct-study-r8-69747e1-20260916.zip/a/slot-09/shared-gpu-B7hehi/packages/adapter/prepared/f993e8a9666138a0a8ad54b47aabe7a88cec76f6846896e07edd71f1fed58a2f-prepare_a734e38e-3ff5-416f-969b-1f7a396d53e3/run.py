import torch
import weakref

_SCALE_X = 1.25
_SCALE_Y = 0.75
_BIAS = 0.125

_CONSTANT_CACHE = {}
_GRAPH_CACHE = {}


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _constants(device, dtype):
    """Cached 0-dim device scalars, so the affine constants cost no host->device copy."""
    key = (device, dtype)
    constants = _CONSTANT_CACHE.get(key)
    if constants is None:
        constants = (
            torch.tensor(-_BIAS, dtype=dtype, device=device),
            torch.tensor(_SCALE_X, dtype=dtype, device=device),
        )
        _CONSTANT_CACHE[key] = constants
    return constants


def _affine_relu(x, y):
    """relu(1.25*x + 0.75*y - 0.125) in three device passes, no redundant copy.

    addcmul folds the x scale and the bias into a single elementwise kernel
    (out = -0.125 + 1.0 * x * 1.25), which the baseline needed two passes for;
    the y term and the relu are then applied in place on that fresh buffer, so
    no input tensor is ever written to.
    """
    if not x.dtype.is_floating_point:
        return torch.relu(x * _SCALE_X + y * _SCALE_Y - _BIAS)
    neg_bias, scale_x = _constants(x.device, x.dtype)
    value = torch.addcmul(neg_bias, x, scale_x)
    value.add_(y, alpha=_SCALE_Y)
    return value.clamp_min_(0)


def _capture(x, y):
    """Record the three-pass chain once so later calls replay it as one launch."""
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        out = _affine_relu(x, y)
    return (weakref.ref(x), weakref.ref(y), graph, out)


def _disabled(x, y):
    return (weakref.ref(x), weakref.ref(y), None, None)


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    key = (id(x), id(y))
    entry = _GRAPH_CACHE.get(key)
    if entry is not None and entry[0]() is x and entry[1]() is y:
        # Identical input objects: the captured graph reads them at their live
        # addresses, so a replay recomputes the result instead of caching it.
        if entry[2] is None:
            return _affine_relu(x, y)
        entry[2].replay()
        return entry[3]

    value = _affine_relu(x, y)

    if x.is_cuda and not torch.cuda.is_current_stream_capturing():
        try:
            entry = _capture(x, y)
        except Exception:
            entry = _disabled(x, y)
        _GRAPH_CACHE[key] = entry
        if entry[2] is not None:
            try:
                entry[2].replay()
                return entry[3]
            except Exception:
                _GRAPH_CACHE[key] = _disabled(x, y)
    return value
