
// Task-owned CPU/C550 process supervisor. No Mission/workflow policy.
import { spawn, execFile } from 'node:child_process';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { access } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
const taskDir = process.argv[2];
const target = (name) => path.join(taskDir, name);
const read = async (name) => { try { return JSON.parse(await readFile(target(name), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } };
const write = async (name, value) => {
  const temporary = target(name + '.' + process.pid + '.tmp');
  await writeFile(temporary, JSON.stringify(value) + '\n', 'utf8');
  // The client and any previous owner of this task can still hold the target
  // handle open while this supervisor publishes its claim. Windows reports
  // that short overlap as EPERM/EBUSY; bounded replacement retries preserve
  // the atomic-write contract without turning a transient handle into a
  // quarantined execution slot.
  for (let attempt = 0; ; attempt += 1) {
    try { await rename(temporary, target(name)); return; }
    catch (error) {
      if (!['EPERM', 'EBUSY', 'EACCES'].includes(error.code) || attempt === 11) throw error;
      await wait(25 * (attempt + 1));
    }
  }
};
const config = await read('execution-config.json');
let claim = await read('execution-claim.json');
let child = null, closed = false, exitCode = null, exitSignal = null;
let stdout = '', stderr = '', stopping = false, cancellation = null, lastNonce = null, treeSignalled = false, signalError = null;
let jobApi = null, jobProcess = null, jobName = null;
// On POSIX, detached children are session/process-group leaders. Keep the
// identity in the durable claim so recovery can explain which group is owned;
// Windows continues to use the Job Object identity below.
let processGroupId = null, sessionId = null;
let resolveClose;
const closedPromise = new Promise((resolve) => { resolveClose = resolve; });
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const closeWithin = (ms) => Promise.race([closedPromise.then(() => true), wait(ms).then(() => false)]);
const groupGone = () => {
  if (!child?.pid) return true;
  if (process.platform === 'win32') return closed && (!cancellation || treeSignalled || exitCode === 0 && exitSignal === null);
  const groupMembers = () => {
    try {
      return readdirSync('/proc').filter((name) => /^\d+$/.test(name)).flatMap((name) => {
        try {
          const stat = readFileSync('/proc/' + name + '/stat', 'utf8');
          const close = stat.lastIndexOf(')');
          if (close < 0) return [];
          const fields = stat.slice(close + 2).trim().split(/\s+/);
          return Number(fields[2]) === Number(child.pid) ? [{ pid: Number(name), state: fields[0] }] : [];
        } catch { return []; }
      });
    } catch { return null; }
  };
  // A negative PID probes the complete process group. ESRCH means that the
  // group no longer exists; EPERM means it still exists but is not signalable
  // by this account, so fail closed and keep the task quarantined.
  try {
    process.kill(-child.pid, 0);
    // Linux may retain an already-reaped process group as an all-zombie
    // entry briefly (notably under WSL). Zombies cannot execute or retain
    // worker resources; treat an all-zombie group as released while still
    // failing closed for any live/unknown member.
    const members = groupMembers();
    return Boolean(members?.length && members.every((member) => member.state === 'Z'));
  }
  catch (error) {
    if (error.code === 'ESRCH') return true;
    if (error.code === 'EPERM') return false;
    // EINVAL/other probe errors are not proof of release.
    return false;
  }
};
const finish = async (confirmed, reason) => {
  if (jobApi) {
    try { stdout = await readFile(target('runner.stdout.raw.log'), 'utf8'); } catch {}
    try { stderr = await readFile(target('runner.stderr.raw.log'), 'utf8'); } catch {}
  }
  await write('runner.stdout.log', stdout);
  await write('runner.stderr.log', stderr);
  await write('execution-exit.json', {
    ownerId: claim.ownerId, supervisorPid: process.pid, pid: child?.pid || null,
    platform: process.platform,
    processGroupId, sessionId,
    jobName: claim.jobName || null, jobObject: Boolean(claim.jobObject),
    exitCode, signal: exitSignal, cancelled: Boolean(cancellation)
      && (cancellation.reason === 'task_deadline' || !(exitCode === 0 && exitSignal === null)),
    cancelReason: cancellation?.reason || null, closed,
    completedAt: confirmed ? new Date().toISOString() : null,
    resourceRelease: { confirmed, status: confirmed ? 'confirmed' : 'quarantined', reason,
      deadline: config.deadlineAt, nextAction: confirmed ? null : 'Inspect or retry cancellation; this execution slot remains occupied.' },
    stdout: stdout.slice(-8192), stderr: stderr.slice(-8192), signalError,
  });
};
const forceStopTreeWithPowerShell = (pid) => new Promise((resolve) => {
  const numericPid = Number(pid);
  if (!Number.isInteger(numericPid) || numericPid <= 0 || closed) return resolve(false);
  const script = [
'$ErrorActionPreference = "Stop"',
'$all = @(Get-CimInstance Win32_Process)',
'$owned = @{}',
'function Collect-Tree([int]$root) {',
'  $item = $all | Where-Object { $_.ProcessId -eq $root } | Select-Object -First 1',
'  if ($null -eq $item) { return }',
'  $owned[$root] = [string]$item.CreationDate',
'  @($all | Where-Object { $_.ParentProcessId -eq $root }) | ForEach-Object { Collect-Tree ([int]$_.ProcessId) }',
'}',
'Collect-Tree ([int]$env:OPERATOR_TREE_PID)',
'if ($owned.Count -eq 0) { exit 17 }',
'$mismatch = $false',
'foreach ($id in @($owned.Keys | Sort-Object -Descending)) {',
'  try { $current = Get-CimInstance Win32_Process -Filter ("ProcessId = " + $id) -ErrorAction Stop } catch { exit 17 }',
'  if ($null -eq $current) { continue }',
'  if ([string]$current.CreationDate -ne $owned[$id]) { $mismatch = $true; continue }',
'  Stop-Process -Id $id -Force -ErrorAction SilentlyContinue',
'}',
'Start-Sleep -Milliseconds 80',
'foreach ($id in $owned.Keys) {',
'  try { $current = Get-CimInstance Win32_Process -Filter ("ProcessId = " + $id) -ErrorAction Stop } catch { exit 17 }',
'  if ($null -ne $current -and [string]$current.CreationDate -eq $owned[$id]) { exit 17 }',
'  if ($null -ne $current -and [string]$current.CreationDate -ne $owned[$id]) { $mismatch = $true }',
'}',
'if ($mismatch) { exit 17 }',
  ].join("; ");
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 2_000, maxBuffer: 64 * 1024, env: { ...process.env, OPERATOR_TREE_PID: String(numericPid) } }, (error) => resolve(!error));
});
const signalTree = (force) => new Promise((resolve) => {
  if (!child?.pid || closed && groupGone()) return resolve(true);
  if (process.platform === 'win32') {
    if (jobApi && jobName) {
      jobApi.terminateJobObject(jobName).then(() => { treeSignalled = true; resolve(true); }).catch((error) => {
        signalError = { code: error.code || 'JOB_OBJECT_TERMINATE_FAILED', message: error.message }; resolve(false);
      });
      return;
    }
    execFile('taskkill.exe', ['/pid', String(child.pid), '/t', ...(force ? ['/f'] : [])],
      { windowsHide: true, timeout: 1_000, maxBuffer: 64 * 1024 }, async (error) => {
        if (!error) return resolve(true);
        signalError = { code: error.code || 'PROCESS_TREE_SIGNAL_FAILED', message: error.message, timedOut: error.killed === true };
        // Fallback validates each PID's CreationDate before stopping it and
        // again afterwards; identity mismatch or a surviving process remains
        // quarantined rather than being reported as released.
        if (!force) return resolve(false);
        forceStopTreeWithPowerShell(child.pid).then(resolve);
      });
  } else {
    // POSIX process-group cancellation remains valid after the group leader
    // exits: descendants may still be alive and are exactly what must be
    // reaped before a task can become terminal. detached:true gives the
    // command its own session/group, so a negative PID cannot hit the
    // supervisor or another task's group.
    try {
      process.kill(-child.pid, force ? 'SIGKILL' : 'SIGTERM');
      treeSignalled = true;
      resolve(true);
    } catch (error) {
      if (error.code === 'ESRCH') return resolve(groupGone());
      signalError = { code: error.code || 'PROCESS_GROUP_SIGNAL_FAILED', message: error.message };
      resolve(false);
    }
  }
});
const stop = async (request) => {
  if (stopping) return;
  stopping = true;
  cancellation = request;
  lastNonce = request.nonce;
  try {
    treeSignalled = await signalTree(false) || treeSignalled;
    await closeWithin(config.cancelStepMs);
    if (!closed || !groupGone()) {
      treeSignalled = await signalTree(true) || treeSignalled;
      await closeWithin(config.cancelStepMs);
    }
    await finish(closed && groupGone(), closed && groupGone() ? 'Owned process tree exited after cancellation.' : 'Process tree did not confirm exit before the cancellation deadline.');
  } finally { stopping = false; }
};
const initialCancel = await read('cancel-request.json')
  || (Date.now() >= Date.parse(config.deadlineAt) ? { reason: 'task_deadline', nonce: 'deadline' } : null);
if (initialCancel) {
  cancellation = initialCancel; closed = true;
  await finish(true, 'Cancellation was observed before a runner process was created.');
} else {
  try {
    if (process.platform === 'win32' && process.env.OPERATOR_WINDOWS_JOB_OBJECT_MODULE) {
      try { await access(process.env.OPERATOR_WINDOWS_JOB_OBJECT_MODULE); jobApi = await import(pathToFileURL(process.env.OPERATOR_WINDOWS_JOB_OBJECT_MODULE).href); } catch { jobApi = null; }
    }
    if (jobApi?.jobObjectSupported?.()) {
      // Job names must be unique per task. Reusing the adapter owner UUID
      // would attach concurrent tasks to one Job and make cancellation unsafe.
      jobName = 'Local\\Acagemm-' + claim.ownerId.replace(/[^a-zA-Z0-9_.-]/g, '_')
        + '-' + path.basename(taskDir).replace(/[^a-zA-Z0-9_.-]/g, '_');
      const comspec = process.env.ComSpec || 'cmd.exe';
      jobProcess = await jobApi.spawnJobObjectProcess({ filePath: comspec, arguments: '/d /s /c "' + config.command + '"',
        cwd: taskDir, stdoutPath: target('runner.stdout.raw.log'), stderrPath: target('runner.stderr.raw.log'), jobName, tempRoot: taskDir });
      child = { pid: jobProcess.helperPid };
      claim = { ...claim, supervisorPid: process.pid, pid: jobProcess.helperPid || null,
        platform: process.platform, jobName, jobObject: true, spawnedAt: new Date().toISOString() };
      jobProcess.result.then((result) => { closed = true; exitCode = result.exitCode; exitSignal = null; resolveClose(); })
        .catch((error) => { stderr += error.message; closed = true; exitCode = 1; exitSignal = null; resolveClose(); });
    } else {
      child = spawn(config.command, {
        cwd: taskDir, shell: true, detached: process.platform !== 'win32', windowsHide: true,
        env: process.env, stdio: ['ignore', 'pipe', 'pipe'],
      });
      processGroupId = process.platform === 'win32' ? null : child.pid || null;
      sessionId = process.platform === 'win32' ? null : child.pid || null;
      child.stdout?.on('data', (chunk) => { stdout = (stdout + chunk).slice(-8 * 1024 * 1024); });
      child.stderr?.on('data', (chunk) => { stderr = (stderr + chunk).slice(-8 * 1024 * 1024); });
      child.once('error', (error) => { stderr += error.code + ': ' + error.message; });
      child.once('close', (code, signal) => {
        closed = true; exitCode = code; exitSignal = signal; resolveClose();
      });
      claim = { ...claim, supervisorPid: process.pid, pid: child.pid || null,
        platform: process.platform,
        processGroupId, sessionId, processGroupSignal: process.platform === 'win32' ? null : 'negative-pid',
        spawnedAt: new Date().toISOString() };
    }
  await write('execution-claim.json', claim);
  while (!closed || stopping) {
    const request = await read('cancel-request.json');
    const expired = Date.now() >= Date.parse(config.deadlineAt);
    if (!stopping && request && request.nonce !== lastNonce) await stop(request);
    else if (!stopping && expired && !cancellation) await stop({ reason: 'task_deadline', nonce: 'deadline' });
    if (!closed) await wait(40);
  }
  if (!cancellation && !groupGone()) await stop({ reason: 'descendant_cleanup', nonce: 'cleanup' });
  await finish(groupGone(), groupGone() ? 'Runner process and owned process tree have exited.' : 'Runner exited but descendant release is unconfirmed.');
  } catch (error) {
    stderr += error.message;
    closed = true; exitCode = 1;
    await finish(false, 'Runner supervision failed before a confirmed release: ' + (error && error.message ? error.message : String(error)));
  }
}
