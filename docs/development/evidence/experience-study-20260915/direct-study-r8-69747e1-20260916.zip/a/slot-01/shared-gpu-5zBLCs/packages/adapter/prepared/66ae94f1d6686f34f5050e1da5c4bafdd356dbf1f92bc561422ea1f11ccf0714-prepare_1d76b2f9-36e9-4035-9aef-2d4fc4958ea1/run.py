import torch

# Fast-path rewrite of relu(1.25*x + 0.75*y - 0.125).
# Every literal below is a dyadic rational, so the algebraic identity used here
# is exact in binary floating point up to ~1 ulp of the result:
#   relu(1.25*x + 0.75*y - 0.125)
#     == relu(2 * (0.625*x + 0.375*y) - 0.125)
#     == 2 * relu(0.5*(1.25*x + 0.75*y) - 0.0625)
#     == 2 * (clamp_min(lerp(x, y, 0.375), 0.0625) - 0.0625)
# This collapses six elementwise kernels (mul, mul, add, sub, relu, clone)
# into three (lerp, clamp_min_, addcmul) and removes the redundant copy.
_LERP_W = 0.375      # 0.625*x + 0.375*y == 0.5 * (1.25*x + 0.75*y)
_SHIFT = 0.0625      # relu(2*t - 0.125) == 2 * clamp_min(t, 0.0625) - 0.125
_SCALE = 2.0
_BIAS = -0.125

# Device/dtype-local 0-dim constants, created once so the hot path never pays a
# host->device transfer (a per-call torch.tensor(...) would cost a launch).
_SCALAR_CACHE = {}


def _bias_and_ones(ref):
    key = (ref.device, ref.dtype)
    cached = _SCALAR_CACHE.get(key)
    if cached is None:
        cached = (
            torch.tensor(_BIAS, device=ref.device, dtype=ref.dtype),
            torch.tensor(1.0, device=ref.device, dtype=ref.dtype),
        )
        _SCALAR_CACHE[key] = cached
    return cached


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def run(inputs):
    # 1) t = 0.625*x + 0.375*y : one fused elementwise kernel, fresh output.
    t = torch.lerp(inputs['x'], inputs['y'], _LERP_W)
    # 2) t = max(t, 0.0625) : equals relu(t - 0.0625) + 0.0625, in place.
    torch.clamp_min(t, _SHIFT, out=t)
    # 3) out = 2*t - 0.125 == relu(1.25*x + 0.75*y - 0.125), single kernel,
    #    no redundant device copy of the result.
    bias, ones = _bias_and_ones(t)
    return torch.addcmul(bias, t, ones, value=_SCALE)
