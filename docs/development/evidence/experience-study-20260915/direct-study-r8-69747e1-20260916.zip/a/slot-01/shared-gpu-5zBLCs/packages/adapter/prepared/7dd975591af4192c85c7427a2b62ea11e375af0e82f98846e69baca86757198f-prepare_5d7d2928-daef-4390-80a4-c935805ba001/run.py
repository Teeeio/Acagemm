"""Single-file implementation of the generic_affine operator (FP32, CUDA).

Baseline semantics (unchanged, and still the correctness oracle):

    out = relu(x * 1.25 + y * 0.75 - 0.125)

Input generation, the 4-case correctness matrix, the 2 benchmark profiles and
``reference(inputs)`` are byte-identical to the mission baseline.  Only the
implementation path called by ``run(inputs)`` is optimized.

Why the baseline is slow
------------------------
For the primary shape (32x256 = 8192 FP32 elements) the arithmetic is
sub-microsecond on any GPU; the measured 15.2 us is per-op dispatch and kernel
launch overhead.  The baseline lowers to six elementwise kernels
(mul, mul, add, sub, relu) plus one redundant device copy (``clone``).

Change 1 - kernel fusion (numerically exact rewrite), 7 launches -> 3:
    t  = lerp(x, y, 3/8)            == x + 3/8*(y - x)  == 5/8 x + 3/8 y
    t  = max(t, 1/16)               (in place, no allocation)
    out= 2*t - 1/8                  == relu(1.25 x + 0.75 y - 0.125)
The identity ``2*max(t, 1/16) - 1/8 == max(2t - 1/8, 0)`` is exact in binary
floating point because 3/8, 1/16, 1/8 are exact dyadic rationals and the final
scaling by 2 is exponent-only.  The only source of deviation from the
reference is the ~1 ulp rounding of the fused two-term sum, which is ~100x
inside the atol/rtol of 1e-5 for the test input range.

Change 2 - launch overhead removal (this round), 3 launches -> 1:
``run`` captures the three-kernel sequence once per (input buffers, shape,
strides, dtype, device) key into a CUDA graph and each subsequent call issues a
single ``cudaGraphLaunch``.  This is NOT result caching: replay re-reads the
live memory of the tensors handed to the call, and the key contains the buffer
addresses, so a call is only served by a graph whose inputs really are the
buffers of that call.  Every call still recomputes the operator from its own
inputs.
If CUDA graphs are unavailable on the runner (capture raises), the module
permanently falls back to the fused 3-launch eager path, which is itself
already correct.
"""

import torch

_LERP_WEIGHT = 0.375   # 3/8   : lerp weight, 5/8 x + 3/8 y
_CLAMP_MIN = 0.0625    # 1/16
_SCALE = 2.0           # 2 * t
_BIAS = -0.125         # -1/8

_GRAPH_CACHE_LIMIT = 24


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


# --------------------------------------------------------------------------
# implementation under test
# --------------------------------------------------------------------------

_CONSTANTS = {}
_GRAPHS = {}
_GRAPH_ENABLED = True


def _bias(device, dtype):
    """Cached 0-dim -1/8 scalar; created outside any capture region."""
    key = (device, dtype)
    value = _CONSTANTS.get(key)
    if value is None:
        value = torch.tensor(_BIAS, device=device, dtype=dtype)
        _CONSTANTS[key] = value
    return value


def _fused(x, y):
    """Three elementwise kernels, one temporary, no redundant copy."""
    t = torch.lerp(x, y, _LERP_WEIGHT)
    torch.clamp_min(t, _CLAMP_MIN, out=t)
    return torch.add(_bias(x.device, x.dtype), t, alpha=_SCALE)


def _cache_key(x, y):
    return (x.data_ptr(), y.data_ptr(),
            tuple(x.shape), tuple(y.shape),
            tuple(x.stride()), tuple(y.stride()),
            x.dtype, x.device.index)


def _capture(x, y):
    """Capture the fused sequence into a replayable CUDA graph."""
    graph = torch.cuda.CUDAGraph()
    side = torch.cuda.Stream()
    side.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(side):
        for _ in range(3):
            _fused(x, y)
    torch.cuda.current_stream().wait_stream(side)
    with torch.cuda.graph(graph):
        out = _fused(x, y)
    return graph, out


def run(inputs):
    global _GRAPH_ENABLED

    x = inputs['x']
    y = inputs['y']

    if not (_GRAPH_ENABLED and x.is_cuda and y.is_cuda
            and x.dtype == y.dtype and x.device == y.device):
        return _fused(x, y)

    key = _cache_key(x, y)
    entry = _GRAPHS.get(key)
    if entry is None:
        try:
            _bias(x.device, x.dtype)   # materialize constants before capture
            entry = _capture(x, y)
        except Exception:
            _GRAPH_ENABLED = False
            return _fused(x, y)
        if len(_GRAPHS) >= _GRAPH_CACHE_LIMIT:
            _GRAPHS.clear()
        _GRAPHS[key] = entry

    graph, out = entry
    graph.replay()
    return out
