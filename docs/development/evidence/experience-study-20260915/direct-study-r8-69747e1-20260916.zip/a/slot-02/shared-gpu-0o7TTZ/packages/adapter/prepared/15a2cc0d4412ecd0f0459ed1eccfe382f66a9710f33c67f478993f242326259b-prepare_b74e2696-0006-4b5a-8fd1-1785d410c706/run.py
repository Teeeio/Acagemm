import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# 0-dim bias tensor cached per (dtype, device): building a CUDA scalar inside
# run() would cost more host time than the arithmetic itself at this size.
_BIAS_CACHE = {}

def _bias_like(x):
    key = (x.dtype, x.device)
    bias = _BIAS_CACHE.get(key)
    if bias is None:
        bias = torch.tensor(-0.125, dtype=x.dtype, device=x.device)
        _BIAS_CACHE[key] = bias
    return bias

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    # 1.25*x + 0.75*y - 0.125 == (-0.125) + 1.25*(x + 0.6*y)
    # 1) one fused scale-and-add kernel; 2) bias add; 3) in-place relu.
    # No .clone(): the accumulator is already a freshly allocated tensor, and
    # nothing is written back into inputs['x'] / inputs['y'].
    acc = torch.add(x, y, alpha=0.6)
    return torch.add(_bias_like(x), acc, alpha=1.25).relu_()
