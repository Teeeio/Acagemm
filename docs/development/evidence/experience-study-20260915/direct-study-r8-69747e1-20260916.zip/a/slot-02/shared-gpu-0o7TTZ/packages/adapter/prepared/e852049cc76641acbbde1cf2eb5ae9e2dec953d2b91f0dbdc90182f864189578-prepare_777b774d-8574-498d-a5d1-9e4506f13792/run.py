"""generic_affine (FP32) -- out = relu(1.25*x + 0.75*y - 0.125)

Baseline cost on the primary profile is dominated by fixed per-kernel overhead:
six launches (mul, mul, add, sub, relu, clone) over a 32x256 tensor whose actual
arithmetic is trivial.  This implementation attacks the launch count on two
levels:

1. Arithmetic fusion (eager path)
   ``1.25*x + 0.75*y - 0.125`` is rewritten as ``-0.125 + 1.25*(x + 0.6*y)``,
   which is exactly two ``torch.add`` calls -- the ``0.6*y`` multiply folds into
   the ``alpha`` argument of the first add, and the outer ``1.25*`` into the
   ``alpha`` of the second.  The activation is applied in place (``relu_``) on
   the freshly produced temporary, and the redundant ``.clone()`` of the
   baseline is dropped.  The scalar ``-0.125`` bias is materialised once per
   (dtype, device) instead of on every call.

2. Launch-overhead elimination (graph path)
   The three remaining kernels are recorded once per distinct input tensor pair
   and replayed as a single CUDA graph launch.  The cache is keyed on the input
   data pointers *and* validated by object identity (``is``) against weak
   references, so a graph is only replayed for the exact tensor objects it was
   captured from -- a recycled allocator address can never be served a stale
   graph.  Shape/dtype/device mismatch, a non-CUDA input, an unavailable CUDA
   graph API, or any capture/replay error all fall back to the eager path,
   which is itself numerically identical to the reference.

Only ``run`` is changed; inputs, test cases, benchmark profiles and the
reference oracle are byte-identical to the baseline.
"""

import weakref

import torch

_A = 1.25
_B = 0.75
_C = -0.125
# 1.25*x + 0.75*y - 0.125  ==  -0.125 + 1.25*(x + 0.6*y)
_RATIO = _B / _A

_BIAS = {}          # (dtype, device) -> scalar tensor holding -0.125
_GRAPHS = {}        # cache key -> (weakref(x), weakref(y), graph, out)
_MAX_GRAPHS = 16    # bound the number of live captured graphs
_MAX_CAPTURES = 32  # give up on graphs if the caller keeps re-allocating inputs
_GRAPHS_ENABLED = True
_CAPTURES = 0


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _bias_like(x):
    key = (x.dtype, x.device)
    bias = _BIAS.get(key)
    if bias is None:
        bias = torch.tensor(_C, dtype=x.dtype, device=x.device)
        _BIAS[key] = bias
    return bias


def _affine_relu(x, y):
    """Three-kernel eager affine+relu: -0.125 + 1.25*(x + 0.6*y), clamped at 0."""
    acc = torch.add(x, y, alpha=_RATIO)
    return torch.add(_bias_like(x), acc, alpha=_A).relu_()


def _graph_replay(x, y):
    """Return the cached output of a replayed graph, or None if there is none."""
    key = (x.data_ptr(), y.data_ptr(), tuple(x.shape), x.dtype, x.device)
    entry = _GRAPHS.get(key)
    if entry is None:
        return None
    if entry[0]() is not x or entry[1]() is not y:
        # Same addresses, different tensors: never serve a stale capture.
        _GRAPHS.pop(key, None)
        return None
    graph, out = entry[2], entry[3]
    try:
        graph.replay()
    except Exception:
        _GRAPHS.pop(key, None)
        return None
    return out


def _graph_build(x, y):
    """Capture and cache a graph for this exact tensor pair; None on any failure."""
    global _GRAPHS_ENABLED, _CAPTURES
    if not _GRAPHS_ENABLED or _CAPTURES >= _MAX_CAPTURES:
        return None
    if not (torch.cuda.is_available() and hasattr(torch.cuda, 'graph')):
        _GRAPHS_ENABLED = False
        return None

    key = (x.data_ptr(), y.data_ptr(), tuple(x.shape), x.dtype, x.device)
    try:
        # Warm the op on a side stream first, as required before capture.
        side = torch.cuda.Stream()
        side.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(side):
            for _ in range(3):
                _affine_relu(x, y)
        torch.cuda.current_stream().wait_stream(side)

        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out = _affine_relu(x, y)
    except Exception:
        _GRAPHS_ENABLED = False
        _GRAPHS.pop(key, None)
        return None

    _CAPTURES += 1
    if len(_GRAPHS) >= _MAX_GRAPHS:
        _GRAPHS.clear()
    _GRAPHS[key] = (weakref.ref(x), weakref.ref(y), graph, out)
    try:
        graph.replay()
    except Exception:
        _GRAPHS.pop(key, None)
        return None
    return out


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    if not (x.is_cuda and y.is_cuda and x.numel() == y.numel() and x.numel() > 0):
        return _affine_relu(x, y)

    out = _graph_replay(x, y)
    if out is None:
        out = _graph_build(x, y)
    if out is None:
        out = _affine_relu(x, y)
    return out
