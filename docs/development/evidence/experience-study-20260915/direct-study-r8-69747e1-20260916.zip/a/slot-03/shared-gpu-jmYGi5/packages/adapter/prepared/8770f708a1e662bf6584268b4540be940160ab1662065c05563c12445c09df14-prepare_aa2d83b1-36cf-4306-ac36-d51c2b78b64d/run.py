import torch

# 0-dim constants for the fused scale/shift tail, materialized once per
# (device, dtype).  Building them inside run() would add a host->device copy and
# a per-call allocation; caching keeps the steady-state path launch-bound.
_CONSTANTS = {}


def _constants_for(device, dtype):
    key = (str(device), dtype)
    pair = _CONSTANTS.get(key)
    if pair is None:
        pair = (
            torch.tensor(-0.125, device=device, dtype=dtype),
            torch.tensor(1.0, device=device, dtype=dtype),
        )
        _CONSTANTS[key] = pair
    return pair


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def run(inputs):
    x = inputs['x']
    y = inputs['y']

    # Exact math: relu(1.25*x + 0.75*y - 0.125) == 1.25*relu(x + 0.6*y - 0.1)
    #                                              == 1.25*max(x + 0.6*y, 0.1) - 0.125
    # (relu is positively homogeneous and max(u, c) - c == relu(u - c) exactly).
    # Each stage is one native single-pass CUDA kernel; x and y stay read-only
    # and the returned tensor is a freshly allocated buffer, so nothing the
    # caller holds aliases an input or an earlier result.
    u = torch.add(x, y, alpha=0.6)   # kernel 1: u = x + 0.6*y
    u.clamp_min_(0.1)                # kernel 2: u = max(u, 0.1)
    bias, one = _constants_for(x.device, x.dtype)
    return torch.addcmul(bias, u, one, value=1.25)   # kernel 3: 1.25*u - 0.125
