import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Bounded optimization vs naive_v0:
    #  - drop the redundant trailing .clone() (an extra full device pass + alloc)
    #  - keep exactly one temporary buffer instead of four, and write every
    #    intermediate in place into it, so the elementwise chain is
    #    4 kernel launches instead of 6.
    # Op order is kept identical to reference(): mul(1.25) -> +y*0.75 -> -0.125 ->
    # relu, so per-element rounding matches the oracle within fp32 ulps.
    # Inputs are never mutated: 'out' is a freshly allocated tensor.
    x = inputs['x']
    y = inputs['y']
    out = torch.mul(x, 1.25)          # out = 1.25 * x  (fresh buffer, no aliasing)
    out.add_(y, alpha=0.75)           # out += 0.75 * y
    out.sub_(0.125)                   # out -= 0.125
    return torch.relu_(out)           # in-place relu, returned as the result
