import torch

# ---------------------------------------------------------------------------
# Fixed operator constants: out = relu(1.25 * x + 0.75 * y - 0.125)
# ---------------------------------------------------------------------------
_SCALE_X = 1.25
_SCALE_Y = 0.75
_BIAS = 0.125

# The eager chain below is already minimal for pure eager PyTorch (4 elementwise
# kernels), and at 32x256 = 8192 FP32 elements the measured cost is essentially
# per-kernel launch/dispatch overhead, not arithmetic.  So instead of shaving
# another kernel, run() captures that same chain once per (shape, dtype, device,
# input-pointer) signature and replays it as a single CUDA graph launch: the
# kernels still execute on the current input contents, but the hot path pays one
# launch instead of four.
#
# Every step is guarded: non-CUDA inputs, an unsupported capture, or an
# unbounded number of distinct input buffers all fall back to the plain eager
# chain, which is bit-identical to the captured path.
_MAX_GRAPHS = 16

_GRAPHS = {}
_GRAPHS_DISABLED = False


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _affine(x, y):
    # One freshly allocated output buffer; both inputs are left untouched.
    out = torch.mul(x, _SCALE_X)
    out.add_(y, alpha=_SCALE_Y)
    out.sub_(_BIAS)
    return torch.relu_(out)


def _signature(x, y):
    return (x.data_ptr(), y.data_ptr(),
            tuple(x.shape), tuple(y.shape),
            tuple(x.stride()), tuple(y.stride()),
            x.dtype, y.dtype, x.device, y.device)


def _capture(x, y):
    # Warm up on a side stream so capture starts from a quiesced state and the
    # allocator has already materialised the output block.
    warmup = torch.cuda.Stream()
    warmup.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(warmup):
        for _ in range(3):
            out = _affine(x, y)
    torch.cuda.current_stream().wait_stream(warmup)

    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        out = _affine(x, y)
    return graph, out


def run(inputs):
    global _GRAPHS_DISABLED
    x = inputs['x']
    y = inputs['y']

    if _GRAPHS_DISABLED or not (x.is_cuda and y.is_cuda):
        return _affine(x, y)

    key = _signature(x, y)
    entry = _GRAPHS.get(key)
    if entry is None:
        if len(_GRAPHS) >= _MAX_GRAPHS:
            _GRAPHS_DISABLED = True
            _GRAPHS.clear()
            return _affine(x, y)
        try:
            entry = _capture(x, y)
        except Exception:
            _GRAPHS_DISABLED = True
            _GRAPHS.clear()
            return _affine(x, y)
        _GRAPHS[key] = entry

    graph, out = entry
    # Re-executes the captured kernels against the current contents of the very
    # same input buffers, onto the same output buffer, on the caller's stream.
    graph.replay()
    return out
