import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_CONST_CACHE = {}

def _bias_and_ones(device, dtype):
    # Broadcast constants (1,1) cached per (device, dtype): the additive bias
    # and a ones tensor used as the "no-op" second operand of addcmul.
    key = (str(device), dtype)
    cached = _CONST_CACHE.get(key)
    if cached is None:
        cached = (
            torch.full((1, 1), -0.125, device=device, dtype=dtype),
            torch.ones((1, 1), device=device, dtype=dtype),
        )
        _CONST_CACHE[key] = cached
    return cached

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    bias, ones = _bias_and_ones(x.device, x.dtype)
    # Same math as the reference, re-associated so that each scalar-weighted
    # term folds into one ternary broadcast kernel, and the activation runs
    # in place on the private temporary (no redundant device copy):
    #   (-0.125 + 0.75*y) + 1.25*x  ==  x*1.25 + y*0.75 - 0.125
    value = torch.addcmul(bias, y, ones, value=0.75)
    value = torch.addcmul(value, x, ones, value=1.25)
    return torch.relu_(value)
