"""Single-file entrypoint for the generic_affine operator (FP32, 32x256).

Round 2 direction (differs from round 1's addcmul/relu_ kernel folding):
the operand set is empty at this size -- 32x256 fp32 is 32 KiB per input -- so
the remaining steady-state cost is expected to be the per-call host-side
launch/dispatch of the elementwise kernels rather than device work. This round
therefore attacks the number of host->device launches instead of the arithmetic:

  1. Leaner eager core: fold the expression into three kernels with no auxiliary
     operand tensors, using the scalar `alpha` of add to carry the coefficients
        1.25*x + 0.75*y - 0.125 == 1.25*(x + 0.6*y) - 0.125
        t = torch.add(x, y, alpha=0.6)      # x + 0.6*y
        t = torch.add(bias, t, alpha=1.25)  # 1.25*t - 0.125
        return torch.relu_(t)               # in-place on a fresh temporary
     (round 1 required a cached ones-tensor operand per addcmul; this drops it)

  2. CUDA-graph replay: once the same (data_ptr, shape, stride, dtype, device)
     key has been seen twice, the three kernels are captured into a
     torch.cuda.CUDAGraph and thereafter executed by a single cudaGraphLaunch.
     Correctness never depends on this path: the capture is validated once
     against an eagerly computed result, and any capture/validation failure
     permanently disables graphs and falls back to the eager core.

Access legality: every touch is an elementwise op over a dense fp32 CUDA buffer.
The captured graph reads exactly the two input buffers that key it (replay is
only ever reached when a live tensor presents that exact pointer/shape/stride
combination, so the bytes read are that tensor's own) and writes only to memory
owned by the graph's private pool. Inputs are never mutated; relu_ runs solely
on a freshly written temporary. Bias constants are kept alive forever per
(device, dtype) so no captured pointer can dangle. No bandwidth claim is made:
this is a launch-count hypothesis, not a measured bandwidth finding.

Baseline anchors (inputs_for / get_inputs / get_test_cases /
get_benchmark_inputs / reference) are preserved unchanged.
"""

import torch

_BIAS_VALUE = -0.125
_ALPHA_SUM = 0.6   # 0.75 / 1.25, so that 1.25 * (x + 0.6*y) == 1.25*x + 0.75*y
_ALPHA_SCALE = 1.25
_MAX_GRAPHS = 8

_biases = {}            # (device, dtype) -> (1, 1) tensor, never freed
_seen = set()           # keys observed once; capture happens on the second sighting
_graphs = {}            # key -> (CUDAGraph, output tensor)
_graphs_enabled = True


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _bias_for(x):
    key = (x.device, x.dtype)
    bias = _biases.get(key)
    if bias is None:
        bias = torch.full((1, 1), _BIAS_VALUE, device=x.device, dtype=x.dtype)
        _biases[key] = bias
    return bias


def _affine(x, y, bias):
    # 1.25*x + 0.75*y - 0.125 == 1.25*(x + 0.6*y) - 0.125, three kernels,
    # no auxiliary operand tensors, no mutation of x or y.
    t = torch.add(x, y, alpha=_ALPHA_SUM)
    t = torch.add(bias, t, alpha=_ALPHA_SCALE)
    return torch.relu_(t)


def _key_for(x, y):
    return (x.data_ptr(), y.data_ptr(), x.shape, x.stride(), y.shape, y.stride(), x.dtype, y.dtype)


def _capture(x, y):
    bias = _bias_for(x)
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(2):
            _affine(x, y, bias)
    torch.cuda.current_stream().wait_stream(stream)

    # One-time oracle: the captured graph must reproduce the eager result exactly.
    expected = _affine(x, y, bias)

    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        out = _affine(x, y, bias)
    graph.replay()
    if not bool(torch.equal(out, expected)):
        raise RuntimeError('captured affine graph did not reproduce the eager result')
    return graph, out


def run(inputs):
    global _graphs_enabled
    x = inputs['x']
    y = inputs['y']

    if _graphs_enabled:
        key = _key_for(x, y)
        entry = _graphs.get(key)
        if entry is not None:
            entry[0].replay()
            return entry[1]
        if key in _seen:
            _seen.discard(key)
            if x.is_cuda and len(_graphs) < _MAX_GRAPHS:
                try:
                    entry = _capture(x, y)
                except Exception:
                    _graphs_enabled = False
                else:
                    _graphs[key] = entry
                    entry[0].replay()
                    return entry[1]
        else:
            _seen.add(key)

    return _affine(x, y, _bias_for(x))
