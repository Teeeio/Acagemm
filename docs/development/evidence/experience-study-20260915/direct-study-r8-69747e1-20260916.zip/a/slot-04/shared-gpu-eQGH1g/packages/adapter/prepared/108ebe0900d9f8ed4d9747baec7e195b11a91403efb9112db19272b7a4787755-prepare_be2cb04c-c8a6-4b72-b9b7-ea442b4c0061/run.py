import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Drop the baseline's redundant trailing .clone() (an extra full-tensor
    # materialization) and collapse the expression into alpha-fused adds.
    # x*1.25 + y*0.75 - 0.125 == (x + 0.75*y) + 0.25*x - 0.125, which needs
    # one fewer kernel launch than the four separate mul/mul/add/sub ops.
    x = inputs['x']
    y = inputs['y']
    acc = torch.add(x, y, alpha=0.75)
    acc = torch.add(acc, x, alpha=0.25, out=acc)
    acc.sub_(0.125)
    return torch.relu_(acc)
