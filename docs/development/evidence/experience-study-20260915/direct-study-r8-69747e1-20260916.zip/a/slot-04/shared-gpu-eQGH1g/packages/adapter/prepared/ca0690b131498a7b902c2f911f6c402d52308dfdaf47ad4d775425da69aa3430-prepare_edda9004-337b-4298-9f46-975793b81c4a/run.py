import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# ---------------------------------------------------------------------------
# Optimized implementation path for run(inputs).
#
# The operator is a pure elementwise map over a 32x256 fp32 tensor (8192
# elements, ~32 KB per operand). At that size the cost of a call is dominated
# by CPU-side per-call overhead -- Python dispatch plus one kernel launch per
# elementwise op -- and not by memory traffic, so the optimization targets
# launch/dispatch count only. (No bandwidth claim is made, and access
# patterns are unchanged: every op is a flat contiguous elementwise pass.)
#
# Bounded changes vs. the baseline implementation:
#   1. the trailing redundant `value.clone()` is removed entirely;
#   2. the affine + ReLU is expressed as four minimal in-place kernels that
#      all write into one buffer instead of five allocating/intermediate ops;
#   3. repeated calls on the *same* input tensor objects (same storage, same
#      version counters) replay a CUDA graph, collapsing the four launches
#      into a single graph launch. Every call still executes the full math on
#      the GPU; the cache is keyed on tensor identity + mutation version and
#      any change to the inputs falls back to a fresh eager computation.
#
# Semantics, shapes, dtypes, devices and tolerance behaviour are unchanged.
# ---------------------------------------------------------------------------

_MAX_CAPTURES = 8      # hard bound on graph captures per process
_MAX_ENTRIES = 32      # hard bound on cached input sets

_STATE = {}
_CAPTURE_ENABLED = True
_CAPTURES = 0


def _affine_relu(x, y, out=None):
    """relu(1.25*x + 0.75*y - 0.125) using four minimal kernels."""
    acc = torch.add(x, y, alpha=0.75, out=out)   # x + 0.75*y
    acc.add_(x, alpha=0.25)                      # 1.25*x + 0.75*y
    acc.sub_(0.125)                              # 1.25*x + 0.75*y - 0.125
    return acc.relu_()


def _capture(x, y):
    """Capture one _affine_relu(x, y) run into a CUDA graph.

    The output buffer is allocated before capture and passed via `out=`, so no
    allocator activity happens inside the capture region.
    """
    static_out = torch.empty_like(x)
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):
            _affine_relu(x, y, static_out)
    torch.cuda.current_stream().wait_stream(stream)
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        _affine_relu(x, y, static_out)
    return graph, static_out


def _maybe_capture(x, y):
    global _CAPTURES, _CAPTURE_ENABLED
    if not _CAPTURE_ENABLED or _CAPTURES >= _MAX_CAPTURES:
        return None, None
    _CAPTURES += 1
    try:
        return _capture(x, y)
    except Exception:
        # Graph capture unavailable (unsupported device, capture conflict, ...):
        # permanently fall back to the eager path.
        _CAPTURE_ENABLED = False
        return None, None


def run(inputs):
    x = inputs['x']
    y = inputs['y']
    key = (id(x), id(y))
    entry = _STATE.get(key)
    if (entry is not None and entry[0] is x and entry[1] is y
            and entry[2] == x._version and entry[3] == y._version):
        graph = entry[4]
        if graph is not None:
            graph.replay()
            return entry[5]
        graph, static_out = _maybe_capture(x, y)
        if graph is not None:
            entry[4] = graph
            entry[5] = static_out
            graph.replay()
            return static_out
        return _affine_relu(x, y)

    out = _affine_relu(x, y)
    graph, static_out = _maybe_capture(x, y)
    if len(_STATE) >= _MAX_ENTRIES:
        _STATE.clear()
    _STATE[key] = [x, y, x._version, y._version, graph, static_out]
    return out
