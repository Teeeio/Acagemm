import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
local = root / '.operator-studio-local'
evidence = root / 'docs/development/evidence/experience-study-20260915'
sha = lambda data: hashlib.sha256(data).hexdigest()
sources = json.loads((local / 'experience-preflight-source.json').read_text(encoding='utf-8'))
for item in sources['files']:
    assert sha((root / item['path']).read_bytes()) == item['sha256'], item['path']
full = (local / 'experience-preflight-full-final.log').read_text(encoding='utf-8-sig')
assert '[release-check] PASS: 149 checks completed' in full
assert '[non-hardware-check] PASS: 44 checks completed without physical hardware' in full
assert json.loads((local / 'experience-preflight-full-final-exit.json').read_text(encoding='utf-8-sig'))['exitCode'] == 0
probe = json.loads((local / 'experience-preflight-real-probe.json').read_text(encoding='utf-8'))
assert probe['records'] == 0
assert len(probe['measurements']) == 2
assert all(m['collectionMs'] < 3000 and m['result']['status'] == 'skipped' for m in probe['measurements'])
names = [
    'experience-preflight-source.json', 'experience-preflight-targeted.log',
    'experience-preflight-targeted-final.log', 'experience-preflight-verifier.log',
    'experience-preflight-refresh.log', 'experience-preflight-adapter.log',
    'experience-preflight-boundaries.log', 'experience-preflight-full.log',
    'experience-preflight-full-final.log', 'experience-preflight-full-final-exit.json',
    'experience-preflight-real-probe.mjs', 'experience-preflight-real-probe.json',
    'experience-preflight-real-probe.log', 'experience-preflight-diff-check.log',
    'archive-experience-preflight.py',
]
archive = evidence / 'environment-preflight-verification-20260916.zip'
assert not archive.exists(), 'Never overwrite an evidence archive'
manifest = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in names:
        data = (local / name).read_bytes()
        manifest.append({'path': name, 'sha256': sha(data), 'bytes': len(data)})
        z.writestr(name, data)
    for item in sources['files']:
        data = (root / item['path']).read_bytes()
        name = 'source/' + item['path']
        manifest.append({'path': name, 'sha256': sha(data), 'bytes': len(data)})
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        assert sha(z.read(item['path'])) == item['sha256']
status_path = evidence / 'status.json'
status = json.loads(status_path.read_text(encoding='utf-8'))
status['updatedAt'] = datetime.now(timezone.utc).isoformat()
status['status'] = 'environment-preflight-software-verified-live-study-pending'
status['environmentPreflightRepair'] = {
    'id': 'R5-collect-cold-environment-query-repair',
    'status': 'software_and_read_only_probe_verified',
    'execution': 'primary_agent_direct_user_authorized',
    'authorization': '用户：已释放空间，继续，目前dispatch平台正在维护，由你自己进行；本轮：开始修复',
    'dispatchTaskId': None,
    'platformContextSyncPending': True,
    'fact': 'Automatic and manual production starts explicitly refresh and match the bound GPU environment before collect. Preflight is capped at 30000ms and remaining original Mission/round time. Collection stays capped at 3000ms; original admission/artifact/queue/evidence verification still runs. Preflight failure, drift, abort or budget exhaustion blocks provider start. A failed cache refresh invalidates the old entry; concurrent readers share the query.',
    'inference': 'Moving the measured cold read into a separate bounded phase removes this demonstrated collection-timeout mechanism. Each relevant start now pays for a fresh environment query, even if the former cache was still valid.',
    'unknown': 'No new full model/GPU E2E or N20 was run on this source. Historical R5 per-stage timings and cache state remain unavailable. Read-only diagnostic used inert evidence/storage ports and cannot prove full historical replay or experience recording. Cancelling preflight rejects its result but a read-only subprocess may finish later; no process-release claim is made.',
    'evidence': ['environment-preflight-verification-20260916.zip', 'budget-terminal-reader-verification-20260916.zip'],
    'next_action': 'Freeze the repaired source and run a new independent real-study plan; retain R5 as 3 completed / 1 budget_terminal / 5 unstarted. Do not merge samples across source revisions or count old N20 as validation of this repair. Resume platform metadata sync only when maintenance ends.',
    'checks': [
        {'command': 'node tests/round-experience-service-test.mjs', 'exitCode': 0, 'passedCases': 14, 'newCases': 4},
        {'command': 'node tests/agent-round-service-test.mjs', 'exitCode': 0},
        {'command': 'node tests/agent-start-context-test.mjs', 'exitCode': 0},
        {'command': 'node tests/shared-gpu-experience-verifier-test.mjs', 'exitCode': 0},
        {'command': 'node tests/shared-gpu-runtime-test.mjs', 'exitCode': 0},
        {'command': 'node tests/local-shared-gpu-package-adapter-test.mjs', 'exitCode': 0},
        {'command': 'npm run verify:non-hardware-robustness', 'exitCode': 0, 'passedChecks': 44, 'includedReleaseChecks': 149, 'source': 'experience-preflight-source.json'},
        {'command': 'node --experimental-vm-modules tests/state-domain-boundary-test.mjs', 'exitCode': 0},
        {'command': 'node tests/module-boundary-test.mjs', 'exitCode': 0},
        {'command': 'git diff --check -- client-runtime tests docs/development/TEAM_HANDOFF.md', 'exitCode': 0},
    ],
    'priorFailures': [
        {'command': 'node tests/round-experience-service-test.mjs (initial test fixture)', 'exitCode': 1, 'reason': 'New test combined CPU hardware with GPU executionMode and hit the existing evidence conflict guard before the intended verifier branch. Fixture corrected to nvidia-gpu; no acceptance rule weakened.'},
    ],
    'intermediateVerification': 'The first full run began before the forced-refresh edge case was fixed. Its log is retained, but final validation uses the separately frozen source and final full run.',
    'reproduction': probe,
    'sourceFiles': sources,
    'archive': {'path': archive.name, 'sha256': sha(archive.read_bytes()), 'files': manifest, 'verified': 'CRC and each SHA256 match original bytes'},
    'notRun': ['new live E2E', 'new N20', 'dispatch platform modifications or task submission'],
}
status['collectTimeoutDiagnosis']['resolutionRef'] = 'environmentPreflightRepair'
status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive': archive.name, 'files': len(manifest), 'sha256': sha(archive.read_bytes()), 'status': status['status']}))
