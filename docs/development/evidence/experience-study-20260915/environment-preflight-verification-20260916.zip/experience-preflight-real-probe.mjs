// Bounded diagnostic: actual resolver/collect timer, inert evidence/storage ports.
// This is not a replay of the full historical verifier and never records evidence.
import { readFile, writeFile } from 'node:fs/promises';
import { createSharedGpuExperiencePreflight } from '../client-runtime/application/shared-gpu-experience-verifier.mjs';
import { performance } from 'node:perf_hooks';
import { createRoundExperienceService } from '../client-runtime/application/round-experience-service.mjs';
import { createSharedGpuEnvironmentResolver, sharedGpuEnvironment } from '../client-runtime/local-shared-gpu-package-adapter.mjs';
const original = 'F:/设计/快速项目/deepseek劳务派遣/.dispatch-data/attempts/run_52c15b22251c4935b1ba1c156423e55a/scratch/slot-04/shared-gpu-DIRubi/affine-state.json';
const { state, tasks } = JSON.parse(await readFile(original, 'utf8'));
const evidence = tasks.findLast((item) => item.result?.experienceEvidence)?.result.experienceEvidence;
if (!evidence) throw Error('Original queue evidence missing');
const mission = state.missions.find((item) => item.id === evidence.missionId);
if (!mission) throw Error('Original Mission missing');
state.activeMissionId = mission.id; // In-memory diagnostic admission, no production mutation.
state.benchmark = { status: 'complete', result: { experienceEvidence: evidence } };
delete state.iterationStats.roundBudget;
state.missionBudgetStartedAt = new Date().toISOString();
state.missionBudgetMs = 720000; // New bounded diagnostic clock; not a historical replay.
const resolver = createSharedGpuEnvironmentResolver({ probeOptions: {
  python: 'F:/设计/快速项目/acagemm原型/.gpu-venv/Scripts/python.exe', requireCudaToolkit: false, timeoutMs: 30000,
} });
let pending;
let records = 0;
const service = createRoundExperienceService({
  experienceService: { retrieve: async () => { throw Error('unused'); },
    recordObservation: async () => { records++; throw Error('No diagnostic evidence may be recorded'); } },
  timers: { setTimeout, clearTimeout },
  resolveAccess: () => ({ projectId: mission.projectId, allowedProjectIds: [] }),
  prepareObservationEvidence: createSharedGpuExperiencePreflight({ environmentResolver: resolver, environmentId: sharedGpuEnvironment.id }),
  verifyObservationEvidence: async () => {
    pending = resolver.resolve(sharedGpuEnvironment.id);
    await pending;
    return { verified: false, code: 'DIAGNOSTIC_PROBE_ONLY' };
  },
});
const measurements = [];
for (const mode of ['cold', 'warm']) {
  const started = performance.now();
  try {
    await service.preflightCollection({ state, mission });
    const preflightMs = performance.now() - started;
    const collectStarted = performance.now();
    const result = await service.collect({ state: structuredClone(state), mission, timeoutMs: 3000,
      observations: [{ evidence }] });
    measurements.push({ mode, preflightMs, collectionMs: performance.now() - collectStarted, elapsedMs: performance.now() - started, result });
  } catch (error) {
    measurements.push({ mode, elapsedMs: performance.now() - started,
      code: error.code, stage: error.stage, effectUnknown: error.effectUnknown });
  }
  // A timed-out collector does not prove its query process stopped. Drain it before
  // measuring the warm case or exiting; preserve both durations explicitly.
  await pending;
  measurements.at(-1).queryDrainedMs = performance.now() - started;
}
const output = { measurements, records,
  scope: 'Actual local read-only GPU resolver and production collect deadline; inert verification/storage ports; no model/candidate execution. Not a historical full-pipeline replay.' };
await writeFile('.operator-studio-local/experience-preflight-real-probe.json', JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(output));
