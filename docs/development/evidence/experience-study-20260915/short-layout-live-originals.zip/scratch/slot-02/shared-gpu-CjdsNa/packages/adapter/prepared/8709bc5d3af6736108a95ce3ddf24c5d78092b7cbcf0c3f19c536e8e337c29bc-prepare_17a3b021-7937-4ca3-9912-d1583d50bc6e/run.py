import torch


def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}


def get_inputs():
    return inputs_for(32, 256)


def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]


def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]


def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)


def _affine_eager(x, y):
    # Single freshly allocated buffer, then only in-place writes: no redundant device copy.
    # Rounding order (mul -> add(alpha) -> sub -> relu) matches reference(inputs).
    out = torch.mul(x, 1.25)
    out.add_(y, alpha=0.75)
    out.sub_(0.125)
    return torch.relu_(out)


def _build_fast_path():
    """Compile the whole affine+relu into one fused, vectorized device kernel.

    Eager execution issues four separate elementwise launches (mul, add, sub, relu);
    at 32x256 the launch overhead dominates the actual arithmetic. A fused kernel
    removes three launches. Any failure degrades to the eager chain, so the
    optimization can never make run() unavailable.
    """
    if not hasattr(torch, 'compile'):
        return None
    try:
        torch._dynamo.config.suppress_errors = True
    except Exception:
        pass
    try:
        return torch.compile(_affine_eager, dynamic=True, fullgraph=True)
    except Exception:
        return None


_fast_path = None
_fast_path_resolved = False


def run(inputs):
    global _fast_path, _fast_path_resolved
    x = inputs['x']
    y = inputs['y']
    if not _fast_path_resolved:
        _fast_path_resolved = True
        _fast_path = _build_fast_path()
    if _fast_path is not None:
        try:
            return _fast_path(x, y)
        except Exception:
            # Backend/compiler failure on any shape: drop to the eager path for good.
            _fast_path = None
    return _affine_eager(x, y)
