import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Bounded round-1 optimization: one allocation + in-place elementwise chain.
    # Baseline materialized 4 temporaries (x*1.25, y*0.75, sum, diff) plus a
    # full-size result copy in relu() and another in clone(): 6 device kernels
    # and 6 allocations for an 8192-element op that is pure launch-bound.
    # Here the same rounding order is kept (mul -> fma-add -> sub -> relu) but
    # every step after the first writes into the single output buffer, so the
    # redundant copy and three temporaries disappear. Inputs are never mutated:
    # mul() allocates the result, all _-suffixed ops only touch that result.
    x = inputs['x']
    y = inputs['y']
    out = torch.mul(x, 1.25)
    out.add_(y, alpha=0.75)
    out.sub_(0.125)
    out.relu_()
    return out
