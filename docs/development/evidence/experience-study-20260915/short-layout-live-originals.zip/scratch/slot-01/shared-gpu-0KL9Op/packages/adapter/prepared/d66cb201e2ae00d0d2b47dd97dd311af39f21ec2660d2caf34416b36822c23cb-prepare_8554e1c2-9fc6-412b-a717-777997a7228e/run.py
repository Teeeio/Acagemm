import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

# Cached broadcast constants (0-dim, one entry per device/dtype).
# They only carry the affine coefficients, so they are reusable across calls
# and across every shape in the test matrix.
_CONST_CACHE = {}

def _consts(device, dtype):
    key = (device, dtype)
    entry = _CONST_CACHE.get(key)
    if entry is None:
        entry = (
            torch.tensor(-0.125, device=device, dtype=dtype),  # additive bias
            torch.tensor(1.25, device=device, dtype=dtype),    # x coefficient
            torch.tensor(0.75, device=device, dtype=dtype),    # y coefficient
        )
        _CONST_CACHE[key] = entry
    return entry

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    bias, k_x, k_y = _consts(x.device, x.dtype)

    # Fuse the bias into the x term: one kernel produces (1.25 * x - 0.125).
    # Broadcasting x and y through TensorIterator keeps the access legal for the
    # non-contiguous y view (y = x.flip(-1)) without assuming any layout.
    value = torch.addcmul(bias, x, k_x)
    # Fold the y*0.75 multiply and the addition into a single in-place kernel.
    value.addcmul_(y, k_y)
    # relu in place: no extra allocation and no extra copy.
    return value.relu_()
