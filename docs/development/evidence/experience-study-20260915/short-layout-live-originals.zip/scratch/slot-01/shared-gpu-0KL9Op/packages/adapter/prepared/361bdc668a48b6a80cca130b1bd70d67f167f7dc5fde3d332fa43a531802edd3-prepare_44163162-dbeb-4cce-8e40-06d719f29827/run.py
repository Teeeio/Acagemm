import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

def run(inputs):
    # Elementwise chain with one allocation and no redundant copy.
    # The baseline materialized five temporaries (x*1.25, y*0.75, their sum,
    # the -0.125 shift, the relu) and then .clone() added a sixth buffer plus a
    # sixth kernel launch. Here `out` is the only new buffer and every op after
    # the first multiply runs in place on it: 4 kernels / 1 allocation.
    # Only the freshly allocated buffer is written; inputs['x'] and inputs['y']
    # are read-only, so repeated benchmark invocations stay bit-identical.
    out = inputs['x'] * 1.25
    out.add_(inputs['y'], alpha=0.75)
    out.sub_(0.125)
    return out.relu_()
