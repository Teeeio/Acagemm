import torch

def inputs_for(rows, cols):
    x = (torch.linspace(-2, 2, rows * cols, device='cuda', dtype=torch.float32) + 3).reshape(rows, cols)
    return {'x': x, 'y': x.flip(-1)}

def get_inputs():
    return inputs_for(32, 256)

def get_test_cases():
    return [
        {'name': 'minimal', 'category': 'minimal', 'inputs': inputs_for(1, 1)},
        {'name': 'representative', 'category': 'representative', 'inputs': get_inputs()},
        {'name': 'boundary', 'category': 'boundary', 'inputs': inputs_for(2, 32)},
        {'name': 'ragged', 'category': 'ragged', 'inputs': inputs_for(3, 17)},
    ]

def get_benchmark_inputs():
    return [{'name': 'primary', 'inputs': get_inputs()}, {'name': 'small', 'inputs': inputs_for(2, 32)}]

def reference(inputs):
    return torch.relu(inputs['x'] * 1.25 + inputs['y'] * 0.75 - 0.125)

_CONSTANTS = {}

def _scalar_constants(like):
    # Pure numeric literals matched to the input's device/dtype. They are not
    # derived from the inputs, so reusing them across calls only removes a
    # host->device scalar transfer from the hot path.
    key = (like.device, like.dtype)
    pair = _CONSTANTS.get(key)
    if pair is None:
        pair = (
            torch.tensor(-0.125, dtype=like.dtype, device=like.device),
            torch.tensor(1.25, dtype=like.dtype, device=like.device),
        )
        _CONSTANTS[key] = pair
    return pair

def run(inputs):
    x = inputs['x']
    y = inputs['y']
    bias, scale = _scalar_constants(x)
    # out = scale * x + bias in a single fused multiply-add kernel.
    out = torch.addcmul(bias, x, scale, value=1.0)
    # Fold the second scaled operand into the same buffer (out += 0.75 * y).
    out.add_(y, alpha=0.75)
    # Activation in place: no extra allocation and no redundant copy.
    return out.relu_()
