import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
const repo=process.cwd(), worker=process.argv[2];
let source=await readFile(path.join(repo,'tests/failed-execution-feedback-test.mjs'),'utf8');
source=source.slice(0, source.indexOf('{\n  // Positive: a fully bound'));
source=source.replace("'../client-runtime/application/shared-gpu-experience-verifier.mjs'", JSON.stringify(pathToFileURL(path.join(worker,'client-runtime/application/shared-gpu-experience-verifier.mjs')).href));
source += `
const probes=[];
for (const [name, mutate] of [
 ['control',f=>{}],
 ['mock source',f=>mutateEnvironment(f,e=>{e.source='mock';})],
 ['CPU environment hardware',f=>mutateEnvironment(f,e=>{e.hardware='cpu';})],
 ['conflicting environment publishable',f=>mutateEnvironment(f,e=>{e.publishable=true;})],
 ['queue target contradicts bound package',f=>{f.task.payload.target={platform:'cpu'};}],
 ['queue adapter contradicts bound package',f=>{f.task.payload.adapter={id:'unknown'};}],
 ['empty typed message',f=>mutateTypedFailure(f,e=>{e.message='';})],
 ['retryable=true typed error',f=>mutateTypedFailure(f,e=>{e.retryable=true;})],
]) {
 const f=structuredClone(baseFixture); mutate(f); assertQueueResultConsistency(f,name);
 const p=await fixtureVerifier(f)({state:f.state,mission:f.mission,observation:f.observation});
 probes.push({name,verified:p.verified,code:p.code??null,expectedVerified:name==='control'});
}
const f=buildFailedFixture({message:'Z'.repeat(5000)});
const proof=await fixtureVerifier(f)({state:f.state,mission:f.mission,observation:f.observation});
console.log(JSON.stringify({fixtureOnly:true,probes,failureSummaryLength:proof.summary.length},null,2));
} finally { await rm(tempRoot,{recursive:true,force:true}); }
`;
const file=path.join(repo,'.operator-studio-local/failure-feedback-20260913/consumer-extra-probes-generated.mjs');
await writeFile(file,source);
const result=spawnSync(process.execPath,[file],{cwd:repo,encoding:'utf8',windowsHide:true});
process.stdout.write(result.stdout||''); process.stderr.write(result.stderr||''); process.exitCode=result.status??1;
