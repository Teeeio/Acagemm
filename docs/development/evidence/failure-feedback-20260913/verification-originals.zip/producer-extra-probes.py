import importlib.util, json, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
root=Path.cwd(); worker=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('fixture',root/'tests/shared-gpu-failure-result-test.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.BASE_RUNNER_PATH=worker/'tools/local-c500-runner.py'
fixture.SHARED_RUNNER_PATH=worker/'tools/local-shared-gpu-runner.py'
results=[]
original_sub=fixture.FakeTensor.__sub__
def shape_checked_sub(self,other):
    if self.shape!=other.shape: raise RuntimeError('shape mismatch while computing numeric diagnostics')
    return original_sub(self,other)
fixture.FakeTensor.__sub__=shape_checked_sub
for name in ['later_oracle_make_inputs','later_candidate_shape','later_candidate_non_tensor']:
    with tempfile.TemporaryDirectory(prefix='root-failure-probe-') as d:
        paths=fixture.prepare_task(Path(d))
        if name=='later_oracle_make_inputs':
            extra='''
_original_cases=get_test_cases
def _broken_inputs():
    raise RuntimeError('oracle case-2 lazy inputs failed')
def get_test_cases():
    cases=_original_cases()
    cases[1].pop('inputs',None)
    cases[1]['make_inputs']=_broken_inputs
    return cases
'''
            with paths['oracle'].open('a',encoding='utf-8') as file:file.write(extra)
        else:
            extra='''
_original_run=run
def run(inputs):
    if inputs['value'].tolist()==[3.0,4.0]:
        return REPLACEMENT
    return _original_run(inputs)
'''.replace('REPLACEMENT',"tensor([1.0])" if name=='later_candidate_shape' else 'None')
            with paths['candidate'].open('a',encoding='utf-8') as file:file.write(extra)
        code=fixture.run_shared(paths)
        value=json.loads((Path(d)/'result.json').read_text(encoding='utf-8'))
        c=value.get('correctness',{})
        results.append({'name':name,'exitCode':code,'error':value.get('error'),'status':c.get('status'),'executedCases':c.get('executedCases'),'passedCases':c.get('passedCases'),'caseResults':c.get('caseResults')})
print(json.dumps({'fixtureOnly':True,'cases':results},indent=2))
