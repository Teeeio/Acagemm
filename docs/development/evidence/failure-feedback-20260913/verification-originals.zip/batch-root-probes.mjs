import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const repo = process.cwd();
const batchPath = process.argv[2];
const { runRegressionBatch } = await import(pathToFileURL(batchPath));
const { readRunRecord } = await import(pathToFileURL(path.join(repo, 'scripts/summarize-gpu-agent-runs.mjs')));
const known = await readRunRecord(path.join(repo, '.tmp-real-agent/shared-gpu-Sx7jVn'));
const unknown = await readRunRecord(path.join(repo, '.tmp-real-agent/shared-gpu-nGBRDg'));
const root = await mkdtemp(path.join(repo, '.operator-studio-local/failure-feedback-20260913/batch-fixtures-'));
const cases = [];
for (const name of ['smoke-good', 'smoke-release-unconfirmed', 'smoke-unknown', 'n20-good', 'n20-last-release-unconfirmed', 'n20-unknown-kept', 'n20-no-summary', 'n20-duplicate', 'n20-config-drift']) {
  const base = path.join(root, name); await mkdir(base);
  const artifactDir = path.join(base, 'artifacts');
  const records = new Map(); let count = 0;
  const result = await runRegressionBatch({ mode: name.startsWith('smoke') ? 'smoke' : 'n20', families:['affine'], artifactDir, reportDir:path.join(base,'reports'), gpuPython:process.execPath }, {
    emit: () => {},
    invokeDriver: async ({index}) => {
      count++;
      const useUnknown = name === 'smoke-unknown' || (name === 'n20-unknown-kept' && index===1);
      const record = structuredClone(useUnknown ? unknown : known);
      const runRoot = path.join(artifactDir, name === 'n20-duplicate' ? 'same' : `fixture-${index}`);
      record.runDir=runRoot;
      record.attempt.attemptId=path.basename(runRoot); record.attempt.runRoot=runRoot;
      if(name.includes('release-unconfirmed') && (name.startsWith('smoke') || index===19)) for(const receipt of record.attempt.cleanup.stopReceipts) receipt.confirmed=false;
      if(name === 'n20-no-summary' && index === 1) record.summary=null;
      if(name === 'n20-config-drift' && index===1) record.attempt.config.code.contentDigest='sha256:'+ 'f'.repeat(64);
      records.set(runRoot,record);
      return { exitCode:0, signal:null, runRoot };
    },
    readRunRecord:async (runRoot)=>records.get(runRoot),
  });
  const expectedPass = ['smoke-good','n20-good'].includes(name);
  const expectedCount = ['smoke-good','smoke-release-unconfirmed','smoke-unknown'].includes(name) ? 1 : ['n20-no-summary','n20-config-drift'].includes(name) ? 2 : 20;
  cases.push({name, status:result.status, exitCode:result.exitCode, strictN20Passed:result.strictN20Passed, stopReason:result.stopReason, invocations:count, ledgerRuns:result.ledger.totals.runs, expectedPass, expectedCount, contractPassed:(result.exitCode===0)===expectedPass && count===expectedCount});
}
await writeFile(path.join(root,'probe-result.json'),JSON.stringify({fixtureOnly:true, root, cases},null,2));
console.log(JSON.stringify({fixtureOnly:true,root,cases},null,2));
process.exitCode=cases.every(c=>c.contractPassed)?0:1;
